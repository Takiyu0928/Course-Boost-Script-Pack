@echo off
rem ============================================================
rem  domooc local-only launcher WITH Marionette (automation ready)
rem
rem  Same as the standard local launcher but adds -marionette so the
rem  auto/ tools can drive this browser on 127.0.0.1:2828.
rem  Marionette listens on loopback only and needs the same user
rem  session. Pure ASCII on purpose.
rem ============================================================
setlocal
cd /d "%~dp0"
title domooc local mode (marionette)

set "ROOT=%~dp0"
set "PROFILE=%ROOT%Profile"
set "FF=%ROOT%App\Firefox64\firefox.exe"

if not exist "%FF%" (
  echo [ERROR] firefox.exe not found at: %FF%
  pause & exit /b 1
)
if not exist "%PROFILE%\prefs.js" (
  echo [ERROR] Profile\prefs.js not found.
  pause & exit /b 1
)
if not exist "%PROFILE%\user.js" (
  echo [ERROR] Profile\user.js is missing.
  echo         Remote channels would stay open - startup aborted.
  pause & exit /b 1
)

if exist "%PROFILE%\parent.lock" del /f /q "%PROFILE%\parent.lock" >nul 2>&1
if exist "%PROFILE%\lock"        del /f /q "%PROFILE%\lock" >nul 2>&1

rem keep the answer service up if node is available and not already running (optional)
set "SVCUP=0"
if exist "%ROOT%answer-service\server.js" (
  where node >nul 2>&1
  if not errorlevel 1 (
    powershell -NoProfile -Command "try{ $c=New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1',8791); $c.Close(); exit 0 }catch{ exit 1 }"
    if errorlevel 1 (
      start "domooc answer service" /min /d "%ROOT%answer-service" node server.js
      set "SVCUP=1"
      timeout /t 2 >nul
    ) else (
      set "SVCUP=1"
    )
  )
)

echo Starting domooc in local-only mode + automation interface ...
echo   - Marionette: 127.0.0.1:2828 (loopback only)
if "%SVCUP%"=="1" echo   - local answer service: http://127.0.0.1:8791
echo   - use: cd auto ^&^& python run.py status
echo.

start "" "%FF%" -marionette -profile "%PROFILE%" -no-remote
exit /b 0
