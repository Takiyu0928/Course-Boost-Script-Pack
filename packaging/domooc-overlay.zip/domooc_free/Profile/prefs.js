// Fresh distribution profile: only domooc extension identities and portable defaults.
user_pref("extensions.webextensions.uuids", "{\"{a48a3858-6b21-4f60-951e-67ba43214267}\":\"6bd7a6b1-0b6c-4002-ae3d-62e1939c6f32\",\"{aecec67f-0d10-4fa7-b7c7-609a2db280cf}\":\"9b05c804-ccab-4b9f-9871-97ce22feccaf\"}");
user_pref("network.dns.localDomains", "domooc.top,www.domooc.top,api.domooc.top");
user_pref("network.trr.mode", 5);
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.aboutwelcome.enabled", false);
user_pref("browser.startup.homepage", "about:blank");
user_pref("browser.newtabpage.enabled", false);
user_pref("toolkit.telemetry.enabled", false);
user_pref("datareporting.healthreport.uploadEnabled", false);
user_pref("extensions.webextensions.ExtensionStorageIDB.migrated.{a48a3858-6b21-4f60-951e-67ba43214267}", true);
user_pref("extensions.webextensions.ExtensionStorageIDB.migrated.{aecec67f-0d10-4fa7-b7c7-609a2db280cf}", true);
