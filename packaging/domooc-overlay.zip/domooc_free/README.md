# README · domooc 本机版（便携部署）

一个**不需要安装、整个文件夹拷走就能用**的定制浏览器包：Firefox 133.0.3 + 预配置 Profile +
两个签名扩展，并且已经把作者服务器（`domooc.top`）从网络层切断、把遥测与自动更新关掉。

- 想直接跑：看 [二、部署三步](#二部署三步)
- 想在一台**新电脑**上把环境配好：看 [一、目标电脑要求](#一目标电脑要求) 和
  [五、环境配置](#五环境配置) 、 [八、常见问题](#八常见问题)
- 点开浏览器之后不知道干什么：看 `首次使用步骤.md`（登录 → 脚本 → 本地题库 → 验证）
- 想知道这包到底是什么、为什么这么改：看 `本地化说明.md`

> 下面所有命令都在 **包根目录**（含 `启动domooc（本机版）.bat` 的那一层）执行。
> 假设包已经被拷到 `D:\domooc_for_myself`，其它路径请自行替换。

---

## 一、目标电脑要求

| 项 | 要求 | 说明 |
| --- | --- | --- |
| 操作系统 | Windows 10 / 11 **64 位** | 本包在 Windows 11 25H2（build 26200）实测；32 位 Windows 不能用 |
| 磁盘空间 | ≥ 400 MB 空闲 | 包本身约 290 MB，首启会生成若干 MB 的 Profile 文件 |
| 运行库 | **无需安装** | VC++ 运行库（`msvcp140.dll` / `vcruntime140*.dll`）随包内置 |
| 浏览器 | **无需安装** | 包里自带 Firefox，和本机已装的 Firefox 互不干扰（独立 Profile + `-no-remote`） |
| 管理员权限 | **不需要** | 只有可选的 hosts 屏蔽需要，见 5.4 |
| 网络 | 首次启动**不需要**联网 | 只有登录中国大学 MOOC、看课程视频时才需要 |
| 注册表 / 系统服务 | **不写、不装** | 删掉文件夹即彻底卸载 |
| Node.js | **可选** | 只有"本地题库答题"用到；不装不影响刷课与视频播放 |
| 介质 | 本地盘或 USB 3.0+ | U 盘启动慢是 U 盘速度问题，不是包的问题 |

---

## 二、部署三步

```text
1) 把整个 domooc_for_myself 文件夹拷到目标电脑（任意盘符、任意路径，含中文也行）

2) 双击  启动domooc（本机版）.bat
   —— 要本地题库答题，改双击  启动domooc（本机版+本地答题服务）.bat

3) 右键  校验本机化.ps1 →「使用 PowerShell 运行」
   —— 看到「通过 N 项，缺口 0 项」即部署完成
```

命令行等价写法（排查时用这个能看到完整输出）：

```bat
cd /d D:\domooc_for_myself
启动domooc（本机版）.bat

:: 自检（PS 5.1 需要 Bypass，脚本本身已带 UTF-8 BOM）
powershell -NoProfile -ExecutionPolicy Bypass -File ".\校验本机化.ps1"
```

---

## 三、首次启动会发生什么

1. 启动器检查 `App\Firefox64\firefox.exe`、`Profile\prefs.js`、`Profile\user.js` 是否齐全，
   缺任何一个都会拒绝启动（**`user.js` 缺失等于远程通道没关**，所以这里故意做成硬失败）。
2. 清理上次异常退出留下的 `Profile\parent.lock` 和 `domooc.top` 站点残留。
3. Firefox 用**绝对路径** `-profile <包目录>\Profile` 启动。
4. 首次运行 Firefox 会在 Profile 里重建两个文件，**属正常现象**：
   - `compatibility.ini`（上次运行的版本/平台记录）
   - `pkcs11.txt`（NSS 安全模块注册表；原包里那份指向 `D:\360极速浏览器下载\Profiles`，
     换机必失效，所以已被移除，改由 Firefox 按当前 Profile 重建）
5. 窗口里出现的是全新的干净会话（缓存、历史会话快照、崩溃记录都已清掉），
   登录状态存在 `Profile\cookies.sqlite` 里，跟着文件夹走。

控制台提示是**英文**的（批处理内容为纯 ASCII，任何系统代码页都能执行），中文说明只在
`.md` / `.txt` 文档里。

---

## 四、目录结构

```text
domooc_for_myself\
├─ 启动domooc（本机版）.bat                 日常入口（纯 ASCII 内容）
├─ 启动domooc（本机版+本地答题服务）.bat     带本地题库的入口
├─ 启动domooc（自动化）.bat                 带 Marionette 的入口（供 auto\ 驱动）
├─ 校验本机化.ps1                          便携性 + 本机化 一键自检
├─ clean-for-distribution.bat              分发前清理（清缓存，保留登录与题库）
├─ 应用本机屏蔽.bat                        可选：写系统 hosts（需管理员）
├─ hosts-block.txt                         可选：hosts 屏蔽清单
├─ README.md                               本文件：环境配置与排障
├─ 便携使用说明.txt                        换机使用要点（记事本直开）
├─ 本地化说明.md                           工具解析、改造清单、回滚方法
├─ 首次使用步骤.md                         点开浏览器之后做什么
├─ 有问题看这里.txt                        原来那份客服话术的本地替代
├─ domooc_原项目逐文件注释.md               原项目的静态审计记录（未改动）
├─ auto\                                   本机自动化（Marionette 驱动，零第三方依赖）
│   ├─ run.py                              CLI：status/login/discover/play/quiz/auto
│   ├─ marionette.py                       Marionette 协议客户端
│   ├─ moocsite.py                         站点逻辑：视频、章节推进、题目提取
│   ├─ browser.py                          实例启动/复用、Profile 副本工具
│   ├─ _test_synthetic.py                  合成页面自测（27 项，不需登录）
│   └─ README.md                           自动化说明与排障
├─ answer-service\                         本地答题服务（127.0.0.1:8791）
│   ├─ server.js                           仅用 Node 标准库，无需 npm install
│   ├─ bank.json                           本地题库
│   └─ README.md                           接口说明与接入步骤
├─ App\Firefox64\                          Mozilla 官方 Firefox 133.0.3，未改造
└─ Profile\                                预配置 + 两个签名扩展 + 本机化加固
    ├─ user.js                             ★ 95 条强制配置（97 KB 里最关键的一个文件）
    ├─ prefs.js                            已同步写入同样的加固项
    ├─ extensions\                         CrackMooc + Violentmonkey（签名 XPI）
    └─ AppData\Mozilla\Firefox\profiles.ini  IsRelative=1 + Path=../../../（便携关键）
```

---

## 五、环境配置

### 5.1 必做项：无

拷贝 + 双击即可。这套东西不含安装包、不写注册表、不建服务、不需要环境变量，
换电脑时唯一要做的是**把整个文件夹拷过去**。

### 5.2 可选：装 Node.js（只有本地题库答题需要）

1. 打开 <https://nodejs.org/> 下载 **LTS** 版（Windows 64 位 `.msi`），一路默认安装。
2. 新开一个命令行验证：

```bat
node -v
:: 期望输出类似 v24.15.0
```

3. 双击 `启动domooc（本机版+本地答题服务）.bat`。
   没有 Node 时该脚本会提示 `local answer service: NOT started`，然后照常只开浏览器 —— 不算故障。

> 服务只用 `http / fs / path / crypto` 四个内置模块，**不需要 `npm install`**，也不联网。
> 未签名脚本被策略拦截时，可用 PowerShell 直接跑：
> `powershell -NoProfile -ExecutionPolicy Bypass -File .\校验本机化.ps1`

### 5.3 可选：把用户脚本接到本地服务

Violentmonkey 里的脚本仍然写着 `https://domooc.top/...`，本机化后该域名不可达，需手工改一次：

```text
浏览器右上角 Violentmonkey 图标 → 找到 domooc 脚本 → 编辑
  · 全部 https://domooc.top  →  http://127.0.0.1:8791
  · @connect 里补一条 127.0.0.1
  · Ctrl+S 保存 → 刷新课程页
```

> 脚本源码存在 Violentmonkey 的 IndexedDB 里，**从外部改写会损坏脚本数据库**，
> 所以只能在界面上手工改。详见 `answer-service\README.md`。

### 5.4 可选：系统级域名屏蔽（需管理员）

```text
右键  应用本机屏蔽.bat →「以管理员身份运行」
```

写入 `C:\Windows\System32\drivers\etc\hosts`（自动备份为 `hosts.domooc.bak`），
把 `domooc.top` 及子域指向本机并刷新 DNS 缓存。不做也不影响工具本身 ——
浏览器层已经用 `network.dns.localDomains` 屏蔽了。

### 5.5 可选：导入本地题库

直接编辑 `answer-service\bank.json`（数组，UTF-8）：

```json
[
  { "q": "题干原文", "options": ["A 选项", "B 选项"], "answer": "B", "index": 1 }
]
```

或运行中追加：

```bat
curl -X POST http://127.0.0.1:8791/api/bank/add ^
  -H "content-type: application/json" ^
  -d "{\"q\":\"题干\",\"options\":[\"甲\",\"乙\"],\"answer\":\"A\"}"
```

匹配顺序：精确 → 题干包含（≥8 字）→ 选项集合完全相同，因此换问法、选项乱序也能命中。

---

## 六、环境自检

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File ".\校验本机化.ps1"
```

它会检查并逐项打勾/报缺口：

| 分组 | 检查内容 |
| --- | --- |
| 1 便携性 | `App\` `Profile\` 是否齐、`profiles.ini` 是否相对路径、`pkcs11.txt` 是否已清除、`.bat` 是否无写死盘符、`.bat` 是否纯 ASCII、`answer-service` 是否在位 |
| 2 本机化 | `Profile\user.js` 是否存在且含关键项、`prefs.js` 里加固项是否真的生效（DNS 屏蔽 / 更新关闭 / 遥测关闭 / TLS 下限） |
| 3 扩展 | 两个扩展是否还在注册表里、三个 XPI 的 SHA256 前缀 |
| 4 域名 | hosts 是否屏蔽（可选）、`domooc.top` 是否仍可公网解析（可解析也不影响，浏览器内已屏蔽） |
| 5 服务 | 本机答题服务是否在线、题库题量 |
| 6 体积 | 文件数与总大小 |

只读，不修改任何文件。判断标准：**缺口 0 项**。

---

## 七、哪些随文件夹走 / 哪些每台机器要重做

| 项 | 是否随文件夹走 |
| --- | --- |
| Firefox 与 Profile、扩展、登录 Cookie、书签历史 | ✅ 跟随（同一个 Profile） |
| 本机化加固（`user.js` / `prefs.js`） | ✅ 跟随 |
| 本地题库 `bank.json`、答题服务 | ✅ 跟随 |
| `pkcs11.txt` / `compatibility.ini` | ❌ 每台机器首启自动重建（已从包里移除） |
| 系统 hosts 屏蔽 | ❌ 每台机器单独执行一次 `应用本机屏蔽.bat` |
| Node.js 运行时 | ❌ 每台机器单独装（没装只是少了本地答题） |
| 浏览器窗口大小/位置、上次打开的标签页 | ❌ 已清除，新的电脑开新窗口 |

---

## 八、常见问题

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 双击 `.bat` 一闪而过 | 某项检查失败 | 用命令行 `cmd` 执行同名 bat，能看到 `[ERROR] ...` 具体原因 |
| 提示 `firefox.exe not found at: ...` | `App\` 被拆开或只拷了部分文件 | 重新整包拷贝，保证 `App\`、`Profile\`、`.bat` 同层 |
| `Profile\user.js is missing` | 缺这个文件 → 远程通道不会关闭 | 从包内补齐；**不要**为了"能启动"而删掉这项检查 |
| `Your Firefox profile cannot be loaded` | 路径不可访问（网络共享 / 权限 / 只拷了一半） | 拷到本地盘；确认 `Profile` 目录完整可读 |
| `Profile is already in use` | 该文件夹正在另一台电脑/另一个实例运行 | 关掉另一处；启动器已会自动删 `parent.lock` |
| 页面提示"网络错误" | `domooc.top` 已被屏蔽，**这是设计结果** | 属预期；不需要修 |
| 答题没反应 | ① 没启动本地服务 ② 脚本基址没改成 `127.0.0.1:8791` | 按 5.2 / 5.3 处理 |
| 控制台/文档中文乱码 | 控制台代码页差异 | 控制台提示是英文的；`.txt` 已带 UTF-8 BOM，用记事本打开正常；`.md` 用 VS Code 或带 UTF-8 支持的编辑器 |
| 视频不播 | 个别站点要求 Widevine/OpenH264，包里 Profile 已自带 `gmp-widevinecdm`、`gmp-gmpopenh264` | 先 `Ctrl+Shift+Del` 清缓存；仍不行检查 `Profile\gmp-*` 目录是否被拷全 |
| 杀软/SmartScreen 拦截 `firefox.exe` | 便携目录里的可执行文件易被误报 | 加白名单；`firefox.exe` 是官方签名文件（附 `.sig`），也可与 `App\Firefox64\firefox.exe.sig` 比对 |
| 时间不对导致证书校验失败 | 系统时间偏差过大 | 校准系统时间后重开 |
| 从 U 盘启动很久 | U 盘随机读写慢 | 拷到本地盘使用 |

---

## 九、卸载 / 清理

1. 直接删除整个 `domooc_for_myself` 文件夹（不残留注册表项与服务）。
2. 若执行过 hosts 屏蔽，还原：

```bat
:: 管理员命令行
copy /y C:\Windows\System32\drivers\etc\hosts.domooc.bak C:\Windows\System32\drivers\etc\hosts
ipconfig /flushdns
```

3. 浏览器里的 MOOC 登录态保存在 `Profile\cookies.sqlite`，随文件夹一起被删除；
   如需保留登录请先备份该文件。

---

## 十、安全须知

1. 本包断掉的是**以后**的外发；改造前是否有账号信息被上传，本机无从判断 ——
   建议到中国大学 MOOC 改一次密码。
2. 建议清一次 `icourse163.org` 的 Cookie 后重新登录，让旧会话失效。
3. 不要再用 `domooc.top/domoocreadme` 和 `admin@domooc.com`，那是同一台服务器的通道。
4. `Profile\user.js` 是这个包的安全核心，**不要删、不要改回**。
   想让这台机器回到"联网原版"：删掉 `Profile\user.js`，再用你自己的 `prefs.js` 备份覆盖
   （本包出厂时没有提供未加固的 `prefs.js`，所以建议先把当前状态另存一份再动）。
5. 想升级 Firefox 或扩展时，整包替换并重新跑一次 `校验本机化.ps1`，
   这样版本变化你能看见（自动更新已被关闭，正是为此）。

---

## 十一、自动化（本机驱动，零第三方依赖）

用 Firefox 自带的 Marionette 本地接口驱动**包里这台浏览器**，复用同一个 Profile
（登录态直接生效），不下载 Chromium、不用 Selenium/Playwright、不连任何外部服务。

```text
1) 双击  启动domooc（自动化）.bat        （带 -marionette 启动，并顺带拉起本地题库服务）
2) 在那个窗口里登录中国大学 MOOC（只需一次，Cookie 长期有效）
3) 命令行：
     cd /d <包目录>\auto
     python run.py status                              看登录态（logged_in / userId）
     python run.py courses                             列出课程（CID、进度、学期状态）
     python run.py videos --course <CID>               列出条目：√=已学 * =视频
     python run.py play --course <CID> --video 2 --speed 1.5 --minutes 10
                                                       真播放第 2 条并盯到结束
     python run.py auto --course <CID> --speed 1.5 --minutes 180
                                                       跳过已学，逐条播放到时间用完
     python run.py quiz --dry-run                      列出题目与将选的选项（不点）
     python run.py quiz                                按本地题库点选（不提交）
     python run.py discover                            导出当前页结构（排查用）
```

**已在真实账号上实测**（某门课）：课程枚举正常；47 个条目 / 13 个视频解析正常；
视频 `currentTime` 连续推进（1.5x、2x 均生效）；250 秒视频 2 倍速播完后站点标记为 `√ 已学`；
`auto` 能跳过已学并从首个待处理视频开始。

- 需要 **Python 3.8+**（仅标准库，`python -V` 自查）；
- 详细契约（真实 DOM 选择器、站点弹窗处理、排障）见 `auto\README.md`；
- 自测（不需登录、不碰真实课程）：`cd auto && python _test_synthetic.py`，27 项全过；
- Marionette 只监听 `127.0.0.1:2828`，等价于"本机可遥控此浏览器"。不想开这个口子就用
  `启动domooc（本机版）.bat`（自动化随之不可用）。

**能力边界**：自动化做的是"真实播放 + 真实点击 + 本地题库答案"。
原版靠远程规则改写播放器、伪装事件来源（`isTrusted`）来规避检测，那部分已随远程通道永久移除，
本包也不复制。所以"跳着刷进度"这类没有保障，让视频真播完才是稳的用法。
**测验不会自动打开**（可能消耗次数）：你手动点开测验页后，`quiz --dry-run` 先看会选什么，
确认后 `quiz` 点选项，**提交永远由你完成**。

---

## 十二、把这个包再发给别的电脑之前

本机跑过浏览器之后，`Profile` 里会长出**与本机强绑定**的东西（缓存、崩溃记录、
`pkcs11.txt`、`compatibility.ini`、会话快照）。直接整包拷走也能用（这些文件 Firefox 会自己处理），
但体积会从 ~290 MB 涨到七八百 MB，且带着本机的浏览痕迹。

先关掉浏览器，再双击：

```text
clean-for-distribution.bat
```

它会删掉：`cache2`、`startupCache`、`crashes`、`minidumps`、`datareporting`、`safebrowsing`、
`shader-cache`、`thumbnails`、`sessionstore*`、`parent.lock`、`pkcs11.txt`、
`compatibility.ini`、`storage\...domooc.top`。
**保留**：登录 Cookie、历史/书签、本地题库 `answer-service\bank.json`。

如果连登录态和历史也不想带走：

```bat
del /q Profile\cookies.sqlite Profile\cookies.sqlite-wal
del /q Profile\places.sqlite  Profile\places.sqlite-wal Profile\favicons.sqlite
```

清理后再跑一次 `校验本机化.ps1`，看到「缺口 0 项」就可以拷给别的电脑了。

> 注意：`pkcs11.txt` 与 `compatibility.ini` 被删是**正常的**，目标机器首次启动会自动重建；
> 自检里 `pkcs11.txt` 缺失或指向当前 Profile 都算通过，只有指向**别的路径**时才提示你清理。
