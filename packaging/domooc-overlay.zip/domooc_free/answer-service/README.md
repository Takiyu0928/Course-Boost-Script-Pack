# 本地答题服务（替代 domooc 云端题库）

只监听 `127.0.0.1`，**不向任何外部服务器发送数据**，昵称 / ID / 邮箱不再上传。
整个文件夹可任意搬盘，路径由脚本自身位置决定（`__dirname`），不写死盘符。

## 启动

双击上级目录的 `启动domooc（本机版+本地答题服务）.bat`（会自动拉起本服务再开浏览器），
或手工：

```bat
cd /d <本文件夹所在路径>\本地答题服务
node server.js
```

- 地址：`http://127.0.0.1:8791`
- 题库：`bank.json`
- 日志：`service.log`（纯本地文本）
- 只依赖 Node.js 自带的 `http/fs/path/crypto`，不需要 `npm install`

Node.js 只用于答题；不装也不影响刷课、视频播放、页面自动化。

## 接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/api/health` | 服务状态 + 题库题量 |
| POST | `/api/identify` | 返回本机标识 `local-xxxx`，不采集账号信息 |
| POST | `/api/answer` | `{question, options}` → 命中返回答案，否则 `found:false` |
| POST | `/api/bank/add` | `{q, options, answer}` → 写入本地题库 |

```bat
curl -X POST http://127.0.0.1:8791/api/answer -H "content-type: application/json" -d "{\"question\":\"题目原文\"}"
```

## 接入用户脚本（必须手工改一次）

Violentmonkey 里的脚本仍然写着 `https://domooc.top/...`，本机化后该域名已被阻断，需要改成：

1. 浏览器右上角 Violentmonkey 图标 → 找到 domooc 脚本 → `编辑`
2. 把脚本里的 `https://domooc.top` 全部替换为 `http://127.0.0.1:8791`
3. `@connect` 一栏同步加 `127.0.0.1`
4. `Ctrl+S` 保存，刷新课程页面

> 脚本源码存在 Violentmonkey 的 IndexedDB 里，外部改动会损坏脚本数据库，所以只能在界面上手工改一次。

## 题库

`bank.json` 是数组，字段：`q`（题干）、`options`（选项数组）、`answer`（答案，字母或文字）、`index`（正确项下标，0 起，可选）。

匹配顺序：精确 → 题干包含（≥8 字）→ 选项集合完全相同。所以同一道题换了问法、选项乱序也能命中。
