// domooc 本机答题服务（替代 domooc.top 的云端题库接口）
// 只监听 127.0.0.1，不向外网发送任何数据。
//
// 启动：node server.js      (默认 http://127.0.0.1:8791)
// 环境变量：PORT / BANK（题库文件路径）
//
// 提供接口：
//   GET  /api/health            → 服务状态与题库规模
//   POST /api/identify          → 本机身份（不采集昵称/ID/邮箱）
//   POST /api/answer            → 命中本地题库则返回答案，未命中返回 found:false
//   POST /api/bank/add          → 把一道题写入本地题库（自建题库）
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8791);
const BANK_PATH = process.env.BANK || path.join(__dirname, 'bank.json');
const LOG_PATH = path.join(__dirname, 'service.log');

function log(...a) {
  const line = `[${new Date().toISOString()}] ${a.join(' ')}\n`;
  fs.appendFileSync(LOG_PATH, line);
}

function loadBank() {
  try {
    const raw = JSON.parse(fs.readFileSync(BANK_PATH, 'utf8'));
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

function saveBank(bank) {
  fs.writeFileSync(BANK_PATH, JSON.stringify(bank, null, 2), 'utf8');
}

// 题干归一化：去掉空白、标点、全半角差异，只看实质文字
function norm(s) {
  return String(s || '')
    .replace(/[\s\u3000]+/g, '')
    .replace(/[，。？！、；：“”‘’（）【】《》,.?!;:"'()\[\]<>]/g, '')
    .replace(/[Ａ-Ｚａ-ｚ０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0))
    .toLowerCase();
}

function findAnswer(bank, question, options) {
  const q = norm(question);
  if (!q) return null;
  // 1) 完全命中
  for (const item of bank) {
    if (norm(item.q) === q) return item;
  }
  // 2) 包含命中（题干前缀差异 / 选项顺序差异常见）
  let best = null;
  let bestLen = 0;
  for (const item of bank) {
    const nq = norm(item.q);
    if (nq.length >= 8 && (q.includes(nq) || nq.includes(q)) && nq.length > bestLen) {
      best = item;
      bestLen = nq.length;
    }
  }
  if (best) return best;
  // 3) 选项集合命中：题干不同但选项完全一致，通常是同一题的变体
  if (Array.isArray(options) && options.length) {
    const key = options.map(norm).sort().join('|');
    for (const item of bank) {
      if (Array.isArray(item.options) && item.options.length === options.length) {
        if (item.options.map(norm).sort().join('|') === key) return item;
      }
    }
  }
  return null;
}

const server = http.createServer((req, res) => {
  const send = (code, obj) => {
    const body = JSON.stringify(obj);
    res.writeHead(code, {
      'content-type': 'application/json; charset=utf-8',
      'content-length': Buffer.byteLength(body),
      'cache-control': 'no-store',
      'access-control-allow-origin': '*',
      'access-control-allow-headers': '*',
      'access-control-allow-methods': 'GET,POST,OPTIONS',
    });
    res.end(body);
  };

  if (req.method === 'OPTIONS') return send(204, {});
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);

  let raw = '';
  req.on('data', (c) => {
    raw += c;
    if (raw.length > 2 * 1024 * 1024) req.destroy();
  });
  req.on('end', () => {
    let body = {};
    if (raw) {
      try { body = JSON.parse(raw); } catch { return send(400, { error: 'bad json' }); }
    }
    const bank = loadBank();

    if (url.pathname === '/api/health') {
      return send(200, { ok: true, mode: 'local-only', bank: bank.length, port: PORT });
    }

    if (url.pathname === '/api/identify') {
      // 本机身份：不采集、不上报任何账号信息，只返回一个本地随机标识
      const id = crypto.createHash('sha256').update(String(process.env.USERNAME || 'local')).digest('hex').slice(0, 12);
      log('identify', '->', id);
      return send(200, { id: `local-${id}`, credits: 999999, local: true });
    }

    if (url.pathname === '/api/answer') {
      const hit = findAnswer(bank, body.question || body.q, body.options);
      if (!hit) {
        log('answer miss', norm(body.question || body.q).slice(0, 60));
        return send(200, { found: false, answer: null, question: body.question || body.q });
      }
      log('answer hit', norm(body.question || body.q).slice(0, 60), '->', hit.answer);
      return send(200, {
        found: true,
        answer: hit.answer,
        index: hit.index ?? null,
        options: hit.options ?? null,
        source: 'local-bank',
        note: hit.note || undefined,
      });
    }

    if (url.pathname === '/api/bank/add' && req.method === 'POST') {
      if (!body.q || !body.answer) return send(400, { error: 'q and answer required' });
      bank.push({
        q: body.q,
        options: body.options || [],
        answer: body.answer,
        index: body.index ?? null,
        note: body.note || 'manual',
        added: new Date().toISOString(),
      });
      saveBank(bank);
      return send(200, { ok: true, bank: bank.length });
    }

    send(404, { error: 'not found', path: url.pathname });
  });
});

server.listen(PORT, '127.0.0.1', () => {
  log('service start on', PORT, 'bank', loadBank().length);
  console.log(`domooc 本机答题服务已启动: http://127.0.0.1:${PORT}`);
  console.log(`题库文件: ${BANK_PATH}  (${loadBank().length} 题)`);
  console.log('仅监听 127.0.0.1，不会向外网发送任何数据。');
});
