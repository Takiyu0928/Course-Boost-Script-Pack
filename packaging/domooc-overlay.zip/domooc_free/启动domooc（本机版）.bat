@echo off
rem ============================================================
rem  domooc local-only launcher
rem  This file is pure ASCII on purpose: batch contents must not
rem  depend on any code page. All paths used here are ASCII.
rem ============================================================
setlocal
cd /d "%~dp0"
title domooc local mode

set "ROOT=%~dp0"
set "PROFILE=%ROOT%Profile"
set "FF=%ROOT%App\Firefox64\firefox.exe"

if not exist "%FF%" (
  echo [ERROR] firefox.exe not found at: %FF%
  echo         Keep App\ , Profile\ and this .bat in the same folder.
  pause & exit /b 1
)
if not exist "%PROFILE%\prefs.js" (
  echo [ERROR] Profile\prefs.js not found.
  pause & exit /b 1
)
if not exist "%PROFILE%\user.js" (
  echo [ERROR] Profile\user.js is missing.
  echo         Remote channels would stay open - startup aborted.
  pause & exit /b 1
)

rem clean locks left behind by a killed session or another machine
if exist "%PROFILE%\parent.lock" del /f /q "%PROFILE%\parent.lock" >nul 2>&1
if exist "%PROFILE%\lock"        del /f /q "%PROFILE%\lock" >nul 2>&1
if exist "%PROFILE%\storage\default\https+++domooc.top" rd /s /q "%PROFILE%\storage\default\https+++domooc.top" >nul 2>&1

echo Starting domooc in local-only mode ...
echo   - domooc.top blocked inside the browser (local DNS override)
echo   - add-on / browser auto-update, telemetry, remote settings: OFF
echo.

start "" "%FF%" -profile "%PROFILE%" -no-remote
exit /b 0
