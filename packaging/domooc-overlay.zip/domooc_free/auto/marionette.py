"""Firefox Marionette 极简客户端（协议 3），零第三方依赖。

用途：以本机方式驱动 domooc 便携包自带的 Firefox，
      复用同一个 Profile（登录态、Cookie 全都在），不引入任何外部下载。

用法：
    from marionette import Marionette
    m = Marionette()          # 连接 127.0.0.1:2828
    m.new_session()
    m.navigate("https://www.icourse163.org")
    m.js("return document.title")
    m.quit()

协议要点（v3）：
    握手：服务端先发 {"applicationType":"gecko","marionetteProtocol":3}，客户端回同样内容
    命令：[0, msgid, name, params]
    响应：[1, msgid, error, result]     error 为 null 表示成功
    所有消息都是 "<长度>:<json>" 形式
"""

import json
import socket
import time


class MarionetteError(Exception):
    pass


class Marionette:
    def __init__(self, host="127.0.0.1", port=2828, timeout=60.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.sock = None
        self.buf = b""
        self.msgid = 0
        self.session_id = None
        self.connect()

    # ---------- 底层收发 ----------
    def connect(self, retries=60, interval=0.5):
        last = None
        for _ in range(retries):
            try:
                self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
                self.sock.settimeout(self.timeout)
                self._handshake()
                return self
            except Exception as e:  # 端口还没起来
                last = e
                self.sock = None
                time.sleep(interval)
        raise MarionetteError("无法连接 Marionette %s:%s (%s)" % (self.host, self.port, last))

    def _recv_exact(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise MarionetteError("连接被关闭")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def _read_message(self):
        # 先读到冒号，拿到长度
        while b":" not in self.buf:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise MarionetteError("连接被关闭")
            self.buf += chunk
        head, rest = self.buf.split(b":", 1)
        length = int(head)
        self.buf = rest
        payload = self._recv_exact(length)
        return json.loads(payload.decode("utf-8"))

    def _send(self, obj):
        data = json.dumps(obj).encode("utf-8")
        self.sock.sendall(str(len(data)).encode("ascii") + b":" + data)

    def _handshake(self):
        hello = self._read_message()          # 服务端问候
        if isinstance(hello, dict) and hello.get("marionetteProtocol"):
            self._send({"applicationType": "gecko", "marionetteProtocol": hello["marionetteProtocol"]})
        else:
            raise MarionetteError("握手响应异常: %r" % (hello,))

    # ---------- 命令 ----------
    def send(self, name, params=None):
        """发命令；若因站点 alert 弹窗失败，自动关掉弹窗并重试一次。

        icourse163 会在"回跳内容页"时弹「请先点开一个课件！」之类提示，
        不处理会让后续所有命令都失败。
        """
        try:
            return self._send_cmd(name, params)
        except MarionetteError as e:
            if "unexpected alert open" not in str(e):
                raise
            self.dismiss_alert()
            return self._send_cmd(name, params)

    def dismiss_alert(self):
        try:
            self._send_cmd("WebDriver:DismissAlert", {})
            return True
        except MarionetteError:
            try:
                self._send_cmd("WebDriver:AcceptAlert", {})
                return True
            except MarionetteError:
                return False

    def _send_cmd(self, name, params=None):
        self.msgid += 1
        mid = self.msgid
        self._send([0, mid, name, params or {}])
        while True:
            msg = self._read_message()
            if isinstance(msg, list) and len(msg) >= 4 and msg[0] == 1 and msg[1] == mid:
                err, result = msg[2], msg[3]
                if err:
                    raise MarionetteError("%s 失败: %s" % (name, err))
                return result
            # 其他 id 的响应（例如上一个命令的延迟响应）丢弃
            if isinstance(msg, list) and len(msg) >= 2 and msg[0] == 1:
                continue

    def new_session(self, capabilities=None):
        res = self.send("WebDriver:NewSession", {"capabilities": capabilities or {}})
        if isinstance(res, dict):
            self.session_id = res.get("sessionId")
        return res

    def navigate(self, url):
        return self.send("WebDriver:Navigate", {"url": url})

    # ---------- 元素 / 框架 / 窗口 ----------
    W3C_ID = "element-6066-11e4-a52e-4f735466cecf"

    @staticmethod
    def _unwrap(res):
        if isinstance(res, dict) and "value" in res and len(res) == 1:
            return res["value"]
        return res

    def find_element(self, css):
        res = self._unwrap(self.send("WebDriver:FindElement", {"using": "css selector", "value": css}))
        if isinstance(res, dict):
            return res.get(self.W3C_ID) or res.get("ELEMENT")
        return None

    # ---------- 真实元素交互（触发浏览器原生事件，前端框架一定会收到） ----------
    def click_element(self, element_uuid):
        return self.send("WebDriver:ElementClick", {"id": {self.W3C_ID: element_uuid}})

    def send_keys(self, element_uuid, text):
        return self.send("WebDriver:ElementSendKeys",
                         {"id": {self.W3C_ID: element_uuid}, "text": text})

    def clear_element(self, element_uuid):
        return self.send("WebDriver:ElementClear", {"id": {self.W3C_ID: element_uuid}})

    def find_elements(self, css):
        res = self._unwrap(self.send("WebDriver:FindElements", {"using": "css selector", "value": css}))
        out = []
        if isinstance(res, list):
            for r in res:
                if isinstance(r, dict):
                    v = r.get(self.W3C_ID) or r.get("ELEMENT")
                    if v:
                        out.append(v)
        return out

    def switch_to_frame(self, element_uuid=None):
        """element_uuid 传 None 表示回到顶层（top）。

        Marionette 需要的是 W3C 元素引用（对象），只传 uuid 字符串会报
        "Unable to locate frame for element"，所以这里统一包成对象。
        """
        if element_uuid is None:
            return self.send("WebDriver:SwitchToFrame", {"focus": True, "id": None})
        if isinstance(element_uuid, int):
            return self.send("WebDriver:SwitchToFrame", {"focus": True, "id": element_uuid})
        ref = {self.W3C_ID: element_uuid}
        try:
            return self.send("WebDriver:SwitchToFrame", {"focus": True, "id": ref})
        except MarionetteError:
            # 兼容旧式引用
            return self.send("WebDriver:SwitchToFrame",
                             {"focus": True, "id": {"ELEMENT": element_uuid}})

    def switch_to_parent_frame(self):
        return self.send("WebDriver:SwitchToParentFrame")

    def switch_to_top(self):
        return self.switch_to_frame(None)

    def window_handles(self):
        return self.send("WebDriver:GetWindowHandles")

    def current_handle(self):
        return self.send("WebDriver:GetWindowHandle")

    def switch_to_window(self, handle):
        return self.send("WebDriver:SwitchToWindow", {"handle": handle, "focus": True})

    def close_window(self):
        return self.send("WebDriver:CloseWindow")

    def get_url(self):
        res = self.send("WebDriver:GetCurrentURL")
        return res.get("value") if isinstance(res, dict) else res

    def get_title(self):
        res = self.send("WebDriver:GetTitle")
        return res.get("value") if isinstance(res, dict) else res

    def js(self, script, *args):
        """在当前页面执行 JS 并返回结果（同步）。"""
        return self.send("WebDriver:ExecuteScript", {"script": script, "args": list(args)})

    def js_async(self, script, *args):
        return self.send("WebDriver:ExecuteAsyncScript", {"script": script, "args": list(args)})

    def screenshot(self, path):
        import base64
        b64 = self.send("WebDriver:TakeScreenshot", {"id": None, "full": True, "hash": False, "scroll": True})
        with open(path, "wb") as f:
            f.write(base64.b64decode(b64))
        return path

    def quit(self):
        try:
            self.send("Marionette:Quit", {"flags": ["eForceQuit"]})
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass


def wait_until(fn, timeout=60.0, interval=0.5, desc="条件"):
    """轮询直到 fn() 返回真值。"""
    end = time.time() + timeout
    while time.time() < end:
        val = fn()
        if val:
            return val
        time.sleep(interval)
    raise MarionetteError("等待超时: %s" % desc)
