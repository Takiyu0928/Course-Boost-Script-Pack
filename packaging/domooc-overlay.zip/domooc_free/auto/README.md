# 自动化（本机驱动，零第三方依赖）

用 Firefox 自带的 **Marionette** 本地接口驱动包里那台浏览器，**复用你自己的 Profile**
（登录态、Cookie 全都在），不下载 Chromium、不装 Playwright/Selenium、不连任何外部服务。

**已在真实账号上实测通过**（2026-10，某门课）：

| 验证项 | 结果 |
| --- | --- |
| 登录态识别 | `logged_in: true`，userId `<uid>` |
| 课程枚举 | 按课程列出进度与学期状态 |
| 课程内容解析 | 47 个条目 / 13 个视频，含 `已学` 标记 |
| 真实播放 | `<video>` 的 `currentTime` 连续推进（1.5x/2x 均生效） |
| 播放完成 | 250 秒视频 2 倍速播完 → 站点标记为 `已学` |
| auto 循环 | 自动跳过已学、从首个待处理视频开始、超时后标记"可续播" |

```
auto\
├─ marionette.py   协议客户端（TCP 2828，JSON，含元素点击/键盘输入/iframe 切换/弹窗自动关闭）
├─ browser.py      启动/复用浏览器实例，Profile 副本工具
├─ moocsite.py     站点逻辑：登录态、课程条目、播放器、题目识别、题库查询
├─ run.py          命令行入口
└─ _test_synthetic.py  合成页面自测（27 项，不需要登录、不碰真实课程）
```

---

## 一、三步开始

```bat
:: 1) 用带 Marionette 的启动器打开浏览器
双击  启动domooc（自动化）.bat

:: 2) 在那个窗口里登录中国大学 MOOC（Cookie 会留在 Profile 里，长期有效）

:: 3) 进入 auto 目录
cd /d <包目录>\auto
python run.py status
```

`status` 里看到 `"logged_in": true` 和 `my_course_url` 就通了。需要 Python 3.8+（仅标准库）。

---

## 二、命令

| 命令 | 作用 |
| --- | --- |
| `python run.py status` | 当前页 / 登录态 / 我的课程地址 |
| `python run.py courses` | 列出「我的课程」全部课程（ID、进度、学期状态） |
| `python run.py videos --course <CID>` | 列出课程全部条目：`√`=已学、`*`=视频、其余为测验/讨论/文档 |
| `python run.py play --course <CID> --video 2 --speed 1.5 --minutes 10` | 打开第 2 个条目，真播放并盯到结束 |
| `python run.py auto --course <CID> --speed 1.5 --minutes 180` | 跳过已学，逐个播放到时间用完 |
| `python run.py auto --course <CID> --force-all` | 连已学的也重播 |
| `python run.py quiz --dry-run` | 识别当前页题目，列出将点选的选项（不点） |
| `python run.py quiz` | 按本地题库答题并点选（**不提交**） |
| `python run.py discover` | 导出当前页结构到 `_discover.json`（站点改版时排查用） |

通用参数：`--port 2828`、`--launch real|test`。

典型一次刷课：

```bat
cd /d <包目录>\auto
python run.py courses                      :: 找到课程 CID
python run.py videos --course <课程CID>   :: 看还有哪些没学
python run.py auto  --course <课程CID> --speed 1.5 --minutes 180
```

---

## 三、真实站点契约（2026-10 实测，改版时按这张表调）

| 元素 | 选择器 / 特征 |
| --- | --- |
| 我的课程 | `https://www.icourse163.org/home.htm?userId=<uid>#/home/course`（旧的 `/mycourse/` 已废弃，对已登录用户也返回"无权访问"） |
| 课程内容页 | `https://www.icourse163.org/learn/<CID>#/learn/content` |
| 章节 | `.m-learnChapterNormal` |
| 小节容器 | `.u-learnLesson` |
| 小节内条目 | `.f-icon.lsicon`，`data-cid` 是课件 ID，内部 `.tag` 文本为 `视频/测验/讨论/文档` |
| 已学标记 | 条目的 class 里含 `learned` |
| 详情页 URL | `#/learn/content?type=detail&id=<contentId>&cid=<data-cid>` |
| 播放器 | 主文档 `#j-video-player` / `.u-edu-h5player` 内的 `<video>`，`src` 是 `blob:`，`duration` 可直接读 |
| 登录成功特征 | 头部无「登录/注册」、有「退出」与 `/home.htm?userId=` 链接、Cookie 含 `NTESSTUDYSI` |

**已知站点行为（工具已处理）：**

- 详情页里条目列表会被替换掉（`iconCount=0`），所以推进必须回内容页重新取列表；
- 回跳内容页时站点会弹「请先点开一个课件！」→ 协议层已实现"遇 alert 自动关闭并重试"；
- 点开视频条目后站点会自动起播，工具只是随后设置倍速并盯进度。

---

## 四、能力边界（重要）

- **播放是真实的**：一直用原生 `video.play()`，进度由平台按实际播放计算。实测 1.5x / 2x 都计入，
  250 秒视频 2 倍速播完后条目变 `√`。
- **不做伪造**：不拦截/改写站点脚本、不伪造 `isTrusted`、不伪造心跳。原版靠远程规则做的
  "反检测"随远程通道一起永久移除，这里不复制。
- **测验不自动打开**：测验可能消耗次数。工具只在**你手动打开测验页之后**工作：
  `quiz --dry-run` 先看会选什么，确认后 `quiz` 点选，**提交永远留给你**。
- **题库是你自己的**：`answer-service\bank.json`。未命中的题写进 `_pending.json`。

---

## 五、答题流程

```text
1) 你在浏览器里点开一个「测验」条目（自己选题、自己看剩余次数）
2) cd auto
   python run.py quiz --dry-run     :: 看到题目、识别到的选项、以及将点选哪一个
3) 确认无误：
   python run.py quiz               :: 只点选项，不提交
4) 你自己核对后点「提交」
```

题库来源见 `answer-service\README.md`；`quiz` 未命中的题会攒到 `auto\_pending.json`。

---

## 六、自测（不碰真实课程）

```bat
cd /d <包目录>\auto
python _test_synthetic.py
```

用 `data:` 合成页面验证 27 项：题目提取（题型标签策略 + 同名选项组策略）、去重与题干还原、
答案映射（A/B/下标/原文）、选项点击与选中结果、视频定位（顶层 + iframe）、框架切换往返、
`watch` 超时不卡死、`dry-run` 不误点。使用 **Profile 副本 + 无头**（副本在系统临时目录）。

---

## 七、排障

| 现象 | 原因 / 处理 |
| --- | --- |
| `Marionette 端口 2828 没有监听` | 浏览器不是用 `启动domooc（自动化）.bat` 起的；或加 `--launch real` |
| `登录态不完整` | 在窗口里重新登录；`login_state` 看头部与 `NTESSTUDYSI` |
| `没解析到条目` | 课程内容页没加载完，或站点改版 → `discover` 看 `items`/`dom`，按第三节的表调 `LIST_ITEMS_JS` |
| 播放器未就绪 | 该条目不是视频（是文档/讨论），或视频需要先点"开始学习"确认 |
| 提示"请先点开一个课件！" | 站点弹窗，已在协议层自动 dismiss；若仍出现，重跑一次命令 |
| 进度不涨 | 检查是否被站点判为后台标签页：保持窗口在前台/不要最小化 |
| `quiz` 识别 0 题 | 当前不是测验页；或题目容器结构变化 → `discover` 看 `questions` |

> 安全：Marionette 只监听 `127.0.0.1`，需要同一用户会话，等价于"本机可遥控这个浏览器"。
> 不想要这个口子就用 `启动domooc（本机版）.bat`（自动化随之不可用）。
