"""合成页面自测：不依赖登录、不碰真实站点，验证自动化逻辑是否正确。

覆盖：
  1. 题目提取（题型标签锚点 + 容器爬升 + 选项去重）
  2. 本地题库查询与答案映射（A/B/C、下标、选项原文）
  3. 选项点击（label + radio 结构）与选中结果
  4. 视频元素定位（顶层 + iframe 一层）
  5. 「下一节」候选识别（dry-run，不真点）
"""
import json
import os
import subprocess
import sys
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.environ.setdefault("DOMOOC_PKG", str(__import__("pathlib").Path(__file__).resolve().parents[1]))

import browser
import moocsite as S
from marionette import Marionette

BANK_PORT = 8792
TMP_BANK = os.path.join(HERE, "_test_bank.json")

QUIZ_HTML = """
<!doctype html><html><head><meta charset="utf-8"><title>synthetic quiz</title></head><body>
<div class="qList">
  <div class="question">
    <div class="stem">1. 下列哪个是中国大学MOOC的域名？（单选题）</div>
    <div class="options">
      <label><input type="radio" name="q1">A. mooc.cn</label>
      <label><input type="radio" name="q1">B. icourse163.org</label>
      <label><input type="radio" name="q1">C. edu.cn</label>
    </div>
  </div>
  <div class="question">
    <div class="stem">2. 本工具是否已经把远程服务移除？（判断题）</div>
    <div class="options">
      <label><input type="radio" name="q2">A. 是</label>
      <label><input type="radio" name="q2">B. 否</label>
    </div>
  </div>
</div>
</body></html>
"""

VIDEO_HTML = """
<!doctype html><html><head><meta charset="utf-8"><title>synthetic player</title></head><body>
<video id="v" width="320" height="180" muted></video>
<a href="#" class="next" onclick="window.__nextClicked=1;return false;">下一节</a>
</body></html>
"""

LABELLESS_HTML = """
<!doctype html><html><head><meta charset="utf-8"><title>labelless quiz</title></head><body>
<div class="quiz">
  <div class="item">
    <p>3. 以下哪个是网易的 MOOC 平台？</p>
    <div class="opts">
      <label><input type="radio" name="q3">mooc.cn</label>
      <label><input type="radio" name="q3">icourse163.org</label>
    </div>
  </div>
</div>
</body></html>
"""


def data_url(html):
    return "data:text/html;charset=utf-8," + urllib.parse.quote(html)


def start_service():
    with open(TMP_BANK, "w", encoding="utf-8") as f:
        json.dump([
            {"q": "下列哪个是中国大学MOOC的域名", "options": ["mooc.cn", "icourse163.org", "edu.cn"], "answer": "B"},
            {"q": "本工具是否已经把远程服务移除", "options": ["是", "否"], "answer": "A"},
        ], f, ensure_ascii=False)
    env = dict(os.environ)
    env["PORT"] = str(BANK_PORT)
    env["BANK"] = TMP_BANK
    p = subprocess.Popen(["node", "server.js"],
                         cwd=os.path.join(browser.PKG, "answer-service"),
                         env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        time.sleep(0.25)
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d/api/health" % BANK_PORT, timeout=1) as r:
                if json.loads(r.read().decode())["ok"]:
                    return p
        except Exception:
            continue
    p.kill()
    raise RuntimeError("测试题库服务未启动")


def check(name, cond, extra=""):
    print(("  [OK]   " if cond else "  [FAIL] ") + name + (("  " + str(extra)) if extra else ""))
    return bool(cond)


def main():
    ok = True
    prof = browser.make_test_profile()
    browser.ensure(profile=prof, headless=True)
    m = Marionette()
    m.new_session()
    svc = start_service()
    try:
        # ---------- 测验页 ----------
        m.navigate(data_url(QUIZ_HTML))
        S.settle(m)
        fpath, data = S.extract_questions(m)
        print("提取结果:", json.dumps(data, ensure_ascii=False)[:500])
        ok &= check("识别到 2 道题", data["count"] == 2, data["count"])
        if data["count"] == 2:
            q1, q2 = data["questions"]
            ok &= check("题干 1 正确", "中国大学MOOC的域名" in q1["q"], q1["q"])
            ok &= check("选项 1 共 3 个", len(q1["options"]) == 3, [o["text"] for o in q1["options"]])
            ok &= check("题型=单选", "单选" in (q1.get("type") or ""), q1.get("type"))

            bank = "http://127.0.0.1:%d/api/answer" % BANK_PORT
            a1 = S.ask_bank(q1["q"], [o["text"] for o in q1["options"]], url=bank)
            ok &= check("题库命中题 1", a1.get("found") is True, a1)
            idx = S.pick_option(q1["options"], a1.get("answer"))
            ok &= check("答案 B -> 下标 1", idx == 1, idx)

            ok &= check("选项计数正确（不含下一题）", len(q1["options"]) == 3,
                        [o["text"] for o in q1["options"]])
            r = S.click_option(m, q1["q"], q1["options"][1]["text"])
            ok &= check("点击选项成功", r and r.get("ok"), r)
            state = S.js(m, """
            var rs = document.querySelectorAll('input[type=radio]');
            return {checked: Array.prototype.map.call(rs, function(x){return x.checked;})};
            """)
            ok &= check("只选中第 2 个 radio",
                        state and state["checked"].count(True) == 1 and state["checked"][1] is True,
                        state)

            a2 = S.ask_bank(q2["q"], [o["text"] for o in q2["options"]], url=bank)
            ok &= check("题库命中判断题", a2.get("found") is True, a2)
            ok &= check("答案 A -> 下标 0", S.pick_option(q2["options"], a2.get("answer")) == 0)
            a3 = S.ask_bank("完全无关的题目内容", [], url=bank)
            ok &= check("未收录返回 found=false", a3.get("found") is False, a3)

            # 纯文本答案（选项原文）也要能映射
            ok &= check("原文答案映射", S.pick_option(q1["options"], "B. icourse163.org") == 1)

        # ---------- 无题型标签的题（只有同名 radio 组，走策略 B）----------
        m.navigate(data_url(LABELLESS_HTML))
        S.settle(m)
        _, data2 = S.extract_questions(m)
        ok &= check("无题型标签也能识别", data2.get("count") == 1, data2.get("count"))
        if data2.get("count") == 1:
            q = data2["questions"][0]
            ok &= check("策略B 题干正确", "网易的 MOOC 平台" in q["q"], q["q"])
            ok &= check("策略B 选项 2 个", len(q["options"]) == 2,
                        [o["text"] for o in q["options"]])
            r2 = S.click_option(m, q["q"], q["options"][1]["text"])
            ok &= check("策略B 点击选项", r2 and r2.get("ok") and r2.get("checked"), r2)

        # ---------- 播放页 ----------
        m.navigate(data_url(VIDEO_HTML))
        S.settle(m)
        vpath, v = S.find_video(m)
        ok &= check("定位到 <video>", bool(v), v)
        if v:
            ok &= check("视频在顶层文档", vpath == [], vpath)
        cands = S.find_next_candidates(m)
        ok &= check("识别「下一节」候选", any("下一节" in c["text"] for c in cands),
                    [c["text"] for c in cands])
        dry = S.click_next(m, dry=True)
        ok &= check("dry-run 不真点", dry["clicked"] is False, dry["text"])
        ok &= check("dry-run 未触发页面点击", not S.js(m, "return window.__nextClicked === 1"))

        before, after = S.video_play(m, speed=1.5)
        ok &= check("video_play 可调用（无源视频状态可读）", isinstance(after, (dict, type(None))), after)

        # 播放盯守循环：无源视频不可能播放，应走超时分支而不是卡死
        t0 = time.time()
        res = S.watch(m, [], max_minutes=0.05, on_tick=lambda v, n: None, stuck_limit=2)
        ok &= check("watch 走超时分支且不卡死",
                    res["ok"] is False and res["reason"] in ("超时", "视频元素消失"),
                    {"reason": res["reason"], "secs": round(time.time() - t0, 1)})

        # ---------- iframe 内的视频 ----------
        outer = ('<!doctype html><html><body><h1>outer</h1>'
                 '<iframe id="f" width="400" height="240" srcdoc="%s"></iframe></body></html>'
                 ) % VIDEO_HTML.replace('"', "&quot;")
        m.navigate(data_url(outer))
        S.settle(m)
        time.sleep(1.8)
        vpath2, v2 = S.find_video(m)
        ok &= check("钻进 iframe 找到视频", bool(v2), {"path_len": len(vpath2 or []), "v": v2})
        if v2:
            S.enter_frames(m, vpath2)
            ok &= check("iframe 内可见 video 元素",
                        S.js(m, "return document.querySelectorAll('video').length") == 1)
            S.enter_frames(m, [])
            ok &= check("回到顶层后只剩外层文档",
                        S.js(m, "return document.querySelectorAll('iframe').length") == 1)
    finally:
        m.quit()
        svc.kill()
        for f in (TMP_BANK,):
            try:
                os.remove(f)
            except Exception:
                pass

    print("\n结果:", "全部通过" if ok else "存在失败项")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
