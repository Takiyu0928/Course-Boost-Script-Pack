"""中国大学 MOOC 站点自动化逻辑（本机、无第三方依赖）。

设计原则：
  1. 不猜站点私有 API，全部走真实页面 DOM；
  2. 点击走真实元素 click()，播放走 <video> 原生接口；
  3. 结构识别不到就只记录、不强行操作（默认 dry-run），避免误提交。

题目识别两条互补策略（都不依赖站点私有类名）：
  A. 题型标签锚点：页面出现「（单选题）/（多选题）/（判断题）」时，从标签处向上
     找「含 >=2 个选项、总文本 <=800」的最内层容器；
  B. 选项组锚点：同名 radio/checkbox 组（>=2 个）的共同祖先，题干 = 容器文本
     去掉各选项文本后的部分。用于站点不渲染题型标签的情况。

识别到题目后会在容器上写 `data-dsh-q`（题干前 60 字），点击时按它定位，
避免"下标错位""题干与选项是兄弟节点"等问题。
"""

import json
import re
import time
import urllib.request

BASE = "https://www.icourse163.org"
TYPE_RE = re.compile(r"[（(]\s*(单选题?|多选题?|判断题?|填空题?|不定项)\s*[)）]")

# ---------------------------------------------------------------- 公共 JS
_JS = r"""
function __dshTxt(e){ return (e && e.textContent || '').replace(/\s+/g,' ').trim(); }
var __dshType = /[（(]\s*(单选题?|多选题?|判断题?|填空题?|不定项)\s*[)）]/;

function __dshStrip(text, opts){
  var t = text;
  for (var i=0;i<opts.length;i++){
    if (opts[i] && t.indexOf(opts[i]) >= 0) t = t.split(opts[i]).join(' ');
  }
  return t.replace(/\s+/g,' ').trim();
}

function __dshOpts(root){
  var cands = root.querySelectorAll('li,label,.option,.u-questionItem div');
  var out = [], seen = {};
  for (var j=0;j<cands.length;j++){
    var el = cands[j], ot = __dshTxt(el);
    if (!ot || ot.length > 200) continue;
    if (__dshType.test(ot)) continue;
    if (seen[ot]) continue;
    seen[ot] = 1;
    out.push({text: ot, tag: el.tagName, checked: !!el.checked});
    if (out.length >= 12) break;
  }
  return out;
}

// 策略 A：题型标签锚点
function __dshRootsByType(){
  var nodes = document.querySelectorAll('div,li,section,dd,p,h3,h4,span');
  var roots = [];
  for (var i=0;i<nodes.length;i++){
    var t = __dshTxt(nodes[i]);
    if (!t || t.length > 400 || !__dshType.test(t)) continue;
    var p = nodes[i], found = null;
    for (var d=0; d<7 && p; d++){
      var o = p.querySelectorAll('li,label,.option,.u-questionItem div');
      if (o.length >= 2 && __dshTxt(p).length <= 800) { found = p; break; }
      p = p.parentElement;
    }
    if (found && roots.indexOf(found) < 0) roots.push(found);
    if (roots.length >= 60) break;
  }
  return roots;
}

// 策略 B：同名 radio/checkbox 组
function __dshRootsByGroup(){
  var inputs = document.querySelectorAll('input[type=radio],input[type=checkbox]');
  var byName = {}, order = [];
  for (var i=0;i<inputs.length;i++){
    var n = inputs[i].name || ('__anon' + i);
    if (!byName[n]) { byName[n] = []; order.push(n); }
    byName[n].push(inputs[i]);
  }
  var roots = [];
  for (var k=0;k<order.length;k++){
    var group = byName[order[k]];
    if (group.length < 2) continue;
    var anc = group[0].parentElement, guard = 0;
    while (anc && guard++ < 10) {
      var allIn = true;
      for (var g=0;g<group.length;g++){ if (!anc.contains(group[g])) { allIn = false; break; } }
      if (allIn) {
        // 只有当"去掉选项文本后还能读出题干"时，这一层才算题目容器；
        // 否则继续向上（.options -> .question）。
        var opts0 = __dshOpts(anc);
        var qt0 = __dshStrip(__dshTxt(anc), opts0.map(function(o){ return o.text; }));
        if (qt0.length >= 4) { if (roots.indexOf(anc) < 0) roots.push(anc); break; }
      }
      anc = anc.parentElement;
    }
  }
  return roots;
}

// 合并、互相包含去重、算题干并打标记
function __dshRoots(){
  var typeRoots = __dshRootsByType();
  // 选项组策略只用来补"没有题型标签"的题：被题型容器包含的直接丢弃
  var groupRoots = __dshRootsByGroup().filter(function(g){
    for (var i=0;i<typeRoots.length;i++){
      if (typeRoots[i] === g || typeRoots[i].contains(g) || g.contains(typeRoots[i])) return false;
    }
    return true;
  });
  var all = typeRoots.concat(groupRoots);
  // 丢掉包含其他候选的外层容器（例如把整份题单当一题）
  var kept = all.filter(function(r, i){
    for (var k=0;k<all.length;k++){
      if (all[k] !== r && r.contains(all[k])) return false;
    }
    return true;
  });
  kept.forEach(function(root){
    var opts = __dshOpts(root);
    var rt = __dshTxt(root);
    var m = rt.match(__dshType);
    var q;
    if (m) {
      q = rt.slice(0, rt.indexOf(m[0])).trim();
    } else {
      q = __dshStrip(rt, opts.map(function(o){ return o.text; }));
      if (q.length > 200) q = q.slice(0, 200);
    }
    if (q) root.setAttribute('data-dsh-q', q);
  });
  return kept.filter(function(r){ return !!r.getAttribute('data-dsh-q'); });
}
"""

EXTRACT_JS = _JS + r"""
var roots = __dshRoots(), out = [], seen = {};
roots.forEach(function(root){
  var q = root.getAttribute('data-dsh-q') || '';
  if (!q || seen[q.slice(0,50)]) return;
  seen[q.slice(0,50)] = 1;
  var m = q.match(__dshType) || (__dshTxt(root).match(__dshType));
  out.push({q: q, type: m ? m[1] : '', options: __dshOpts(root)});
});
return {count: out.length, questions: out.slice(0, 40)};
"""

CLICK_OPTION_JS = _JS + r"""
var qtext = String(arguments[0] || ''), otext = String(arguments[1] || '');
__dshRoots();
var roots = document.querySelectorAll('[data-dsh-q]');
var key = qtext.slice(0, 20), root = null;
for (var i=0;i<roots.length;i++){
  var v = roots[i].getAttribute('data-dsh-q') || '';
  if (v.indexOf(key) >= 0 || key.indexOf(v.slice(0,20)) >= 0) { root = roots[i]; break; }
}
if (!root) return {ok:false, why:'没找到题干容器'};
var cands = root.querySelectorAll('li,label,.option,.u-questionItem div');
var target = null;
for (var j=0;j<cands.length;j++){
  var ot = __dshTxt(cands[j]);
  if (ot === otext || (ot && ot.indexOf(otext) === 0)) { target = cands[j]; break; }
}
if (!target) return {ok:false, why:'没找到选项文本'};
try { target.click(); } catch(e){ target.dispatchEvent(new MouseEvent('click',{bubbles:true})); }
var after = target.querySelector('input') || target;
return {ok:true, clicked: __dshTxt(target), checked: !!after.checked};
"""

VIDEO_JS = r"""
var v = document.querySelector('video');
if (!v) return null;
return {
  src: (v.currentSrc || v.src || '').slice(0,120),
  duration: v.duration || 0, currentTime: v.currentTime || 0,
  paused: v.paused, rate: v.playbackRate, readyState: v.readyState,
  ended: v.ended, muted: v.muted, w: v.videoWidth, h: v.videoHeight
};
"""


# ---------------------------------------------------------------- 基础
def js(m, script, *args):
    res = m.js(script, *args)
    return res.get("value") if isinstance(res, dict) else res


def settle(m, timeout=25.0, quiet=2):
    last, stable = None, 0
    end = time.time() + timeout
    while time.time() < end:
        try:
            st = js(m, "return {r:document.readyState,u:location.href}")
        except Exception:
            time.sleep(0.3)
            continue
        if st and st.get("r") == "complete":
            if last and st["u"] == last:
                stable += 1
                if stable >= quiet:
                    time.sleep(0.3)
                    return st["u"]
            else:
                stable = 0
            last = st["u"]
        time.sleep(0.4)
    return last


def info(m):
    return js(m, r"""
    return {
      url: location.href, title: document.title, ready: document.readyState,
      bodyLen: document.body ? document.body.innerText.length : 0,
      frames: document.querySelectorAll('iframe').length,
      videos: document.querySelectorAll('video').length,
      head: document.body ? document.body.innerText.slice(0,120).replace(/\s+/g,' ') : ''
    };
    """) or {}


# ---------------------------------------------------------------- 登录态
HOME_URL = BASE + "/"
# 注意：/mycourse/ 这个老地址对已登录用户也会返回「无权访问」，
# 真正入口是 home.htm?userId=<uid>#/home/course，uid 从头部「个人中心」链接里取。
MY_COURSE_TPL = BASE + "/home.htm?userId=%s#/home/course"


def _home_probe(m):
    return js(m, r"""
    var body = document.body ? document.body.innerText.replace(/\s+/g,' ') : '';
    var head = body.slice(0, 260);
    var loginEntry = /登录\s*[\|/]\s*注册|登录\/注册/.test(head)
                     || !!document.querySelector('a[href*="member/login"]');
    var exitLink = !!document.querySelector('a[href*="member/logout"]');
    var uid = '';
    var nodes = document.querySelectorAll('a[href*="/home.htm?userId="]');
    for (var i=0;i<nodes.length;i++){
      var mm = (nodes[i].getAttribute('href')||'').match(/userId=(\d+)/);
      if (mm) { uid = mm[1]; break; }
    }
    if (!uid) {
      var m2 = (document.cookie.match(/STUDY_INFO=([^;]+)/) || [])[1] || '';
      var d2 = '';
      try { d2 = decodeURIComponent(m2); } catch(e) { d2 = m2; }
      var m3 = d2.match(/"userId"\s*:\s*"?(\d+)/) || d2.match(/userId=(\d+)/);
      if (m3) uid = m3[1];
    }
    return {hasLoginEntry: loginEntry, exitLink: exitLink, userId: uid,
            hasStudyCookie: /NTESSTUDYSI/.test(document.cookie),
            head: head.slice(0, 140)};
    """) or {}


def login_state(m, navigate=True):
    """基于首页头部 + Cookie 判定登录态（不再依赖已废弃的 /mycourse/）。"""
    if navigate:
        m.navigate(HOME_URL)
    url = settle(m) or ""
    d = _home_probe(m)
    logged = (not d.get("hasLoginEntry")) and bool(d.get("exitLink") or d.get("userId")) \
        and bool(d.get("hasStudyCookie"))
    hint = ""
    if not logged:
        if d.get("hasLoginEntry"):
            hint = "首页仍显示「登录/注册」：未登录"
        elif not d.get("hasStudyCookie"):
            hint = "缺少 NTESSTUDYSI 会话 Cookie：未登录或已过期"
        else:
            hint = "登录态不完整，建议在浏览器窗口里重新登录"
    return {"logged_in": bool(logged), "url": url, "user_id": d.get("userId", ""),
            "my_course_url": (MY_COURSE_TPL % d["userId"]) if d.get("userId") else "",
            "hint": hint}


def wait_for_login(m, timeout=600, poll=3):
    print("请在浏览器窗口里完成登录，自动化在后台等待（最多 %d 秒）..." % timeout)
    end = time.time() + timeout
    while time.time() < end:
        st = login_state(m)
        if st["logged_in"]:
            print("已检测到登录态:", st["url"])
            return True
        time.sleep(poll)
    return False


# ---------------------------------------------------------------- 视频
def find_video(m, max_iframes=8, depth=2):
    m.switch_to_top()
    v = js(m, VIDEO_JS)
    if v:
        return [], v
    frames = m.find_elements("iframe")
    for fuuid in frames[:max_iframes]:
        try:
            m.switch_to_top()
            m.switch_to_frame(fuuid)
            v = js(m, VIDEO_JS)
            if v:
                return [fuuid], v
            if depth > 1:
                for juuid in m.find_elements("iframe")[:max_iframes]:
                    try:
                        m.switch_to_top()
                        m.switch_to_frame(fuuid)
                        m.switch_to_frame(juuid)
                        v = js(m, VIDEO_JS)
                        if v:
                            return [fuuid, juuid], v
                    except Exception:
                        continue
        except Exception:
            continue
    m.switch_to_top()
    return None, None


def enter_frames(m, path):
    m.switch_to_top()
    for uuid in path or []:
        m.switch_to_frame(uuid)


def video_play(m, speed=1.0, mute=True):
    before = js(m, VIDEO_JS)
    js(m, """
    var v = document.querySelector('video');
    if (!v) return false;
    try { v.muted = %s; } catch(e){}
    try { v.playbackRate = %s; } catch(e){}
    try { v.play(); } catch(e){}
    return true;
    """ % ("true" if mute else "false", float(speed)))
    time.sleep(1.5)
    return before, js(m, VIDEO_JS)


def watch(m, frame_path, max_minutes=90, on_tick=None, stuck_limit=12):
    enter_frames(m, frame_path)
    start = time.time()
    last_cur, stuck, last_report = -1.0, 0, 0.0
    while time.time() - start < max_minutes * 60:
        v = js(m, VIDEO_JS)
        if not v:
            return {"ok": False, "reason": "视频元素消失（可能已跳转）", "last": None}
        if v["ended"]:
            return {"ok": True, "reason": "播放结束", "last": v}
        if abs(v["currentTime"] - last_cur) < 0.5:
            stuck += 1
            if stuck >= stuck_limit:
                js(m, "var v=document.querySelector('video'); if(v){try{v.play()}catch(e){}} return true;")
                stuck = 0
                if on_tick:
                    on_tick(v, "检测到停顿，已尝试继续播放")
        else:
            stuck = 0
        last_cur = v["currentTime"]
        if on_tick and time.time() - last_report > 15:
            last_report = time.time()
            on_tick(v, None)
        time.sleep(2)
    return {"ok": False, "reason": "超时", "last": js(m, VIDEO_JS)}


# ---------------------------------------------------------------- 章节推进
NEXT_KEYWORDS = ["下一节", "下一讲", "下一单元", "下一章", "下一课", "下一个", "下一活动", "下一小节"]


def find_next_candidates(m):
    return js(m, r"""
    var kw = %s;
    var out = [];
    var all = document.querySelectorAll('a,button,li,span,div');
    for (var i=0;i<all.length;i++){
      var el = all[i], t = (el.textContent||'').trim();
      if (!t || t.length > 12) continue;
      for (var k=0;k<kw.length;k++){
        if (t.indexOf(kw[k]) >= 0) {
          var r = el.getBoundingClientRect();
          if (r.width > 0 && r.height > 0) {
            out.push({text: t, tag: el.tagName, cls: String(el.className||'').slice(0,40)});
            break;
          }
        }
      }
      if (out.length >= 10) break;
    }
    return out;
    """ % json.dumps(NEXT_KEYWORDS, ensure_ascii=False)) or []


def click_next(m, prefer_text=None, dry=True):
    cands = find_next_candidates(m)
    if not cands:
        return {"clicked": False, "text": None, "candidates": []}
    target = next((c for c in cands if prefer_text and prefer_text in c["text"]), cands[0])
    if dry:
        return {"clicked": False, "text": target["text"], "candidates": cands, "dry": True}
    ok = js(m, r"""
    var kw = %s, want = %s;
    var all = document.querySelectorAll('a,button,li,span,div');
    var pick = null;
    for (var i=0;i<all.length;i++){
      var el = all[i], t = (el.textContent||'').trim();
      if (!t || t.length > 12) continue;
      for (var k=0;k<kw.length;k++){
        if (t.indexOf(kw[k]) >= 0) {
          var r = el.getBoundingClientRect();
          if (r.width > 0 && r.height > 0) {
            if (want && t.indexOf(want) < 0) continue;
            pick = el; break;
          }
        }
      }
      if (pick) break;
    }
    if (!pick) return false;
    try { pick.click(); } catch(e){ pick.dispatchEvent(new MouseEvent('click',{bubbles:true})); }
    return true;
    """ % (json.dumps(NEXT_KEYWORDS, ensure_ascii=False), json.dumps(prefer_text or "", ensure_ascii=False)))
    return {"clicked": bool(ok), "text": target["text"], "candidates": cands}


# ---------------------------------------------------------------- 题目
def extract_questions(m, max_iframes=8):
    m.switch_to_top()
    res = js(m, EXTRACT_JS)
    if res and res.get("count"):
        return [], res
    for fuuid in m.find_elements("iframe")[:max_iframes]:
        try:
            m.switch_to_top()
            m.switch_to_frame(fuuid)
            res = js(m, EXTRACT_JS)
            if res and res.get("count"):
                return [fuuid], res
        except Exception:
            continue
    m.switch_to_top()
    return None, {"count": 0, "questions": []}


def click_option(m, q_text, option_text):
    return js(m, CLICK_OPTION_JS, q_text, option_text)


# ---------------------------------------------------------------- 课程内容页（实测结构）
# 章节：.m-learnChapterNormal   小节容器：.u-learnLesson
# 小节内的条目：.f-icon.lsicon，其中 .tag 文本为 视频/测验/讨论/文档
# 点条目后 URL 变成 #/learn/content?type=detail&id=<contentId>&cid=<courseId>
# 播放器：主文档里的 #j-video-player / .u-edu-h5player 内的 <video>（blob 源）
CONTENT_URL = BASE + "/learn/%s#/learn/content"

LIST_ITEMS_JS = r"""
var out = [];
function titleOf(box){
  var el = box.querySelector('.title, .j-title, h3, .f-fl');
  return el ? (el.textContent||'').replace(/\s+/g,' ').trim().slice(0,40) : '';
}
var lessons = document.querySelectorAll('.u-learnLesson');
for (var i=0;i<lessons.length;i++){
  var box = lessons[i];
  var lt = titleOf(box);
  var icons = box.querySelectorAll('.f-icon.lsicon');
  for (var j=0;j<icons.length;j++){
    var tg = icons[j].querySelector('.tag');
    var tag = tg ? (tg.textContent||'').trim() : '';
    var txt = (icons[j].textContent||'').replace(/\s+/g,' ').trim();
    if (tag && txt.indexOf(tag) === 0) txt = txt.slice(tag.length).trim();
    out.push({gi: out.length, lesson: i, lessonTitle: lt, tag: tag, title: txt.slice(0,50),
              learned: (' ' + String(icons[j].className||'') + ' ').indexOf(' learned ') >= 0,
              cid: icons[j].getAttribute('data-cid') || ''});
  }
}
if (!out.length) {
  var icons2 = document.querySelectorAll('.f-icon.lsicon');
  for (var k=0;k<icons2.length;k++){
    var tg2 = icons2[k].querySelector('.tag');
    var tag2 = tg2 ? (tg2.textContent||'').trim() : '';
    var txt2 = (icons2[k].textContent||'').replace(/\s+/g,' ').trim();
    if (tag2 && txt2.indexOf(tag2) === 0) txt2 = txt2.slice(tag2.length).trim();
    out.push({gi: out.length, lesson: -1, lessonTitle: '', tag: tag2, title: txt2.slice(0,50),
              learned: (' ' + String(icons2[k].className||'') + ' ').indexOf(' learned ') >= 0,
              cid: icons2[k].getAttribute('data-cid') || ''});
  }
}
return out;
"""


def open_course(m, course_id):
    m.navigate(CONTENT_URL % course_id)
    settle(m)
    time.sleep(2.5)
    return m.get_url()


def list_items(m):
    """列出课程内容页里的全部条目（gi 是全局下标，供 click_item 用）。"""
    return js(m, LIST_ITEMS_JS) or []


def click_item(m, gi):
    """点击第 gi 个条目，返回是否点击成功。"""
    return js(m, r"""
    var icons = document.querySelectorAll('.f-icon.lsicon');
    var el = icons[arguments[0]];
    if (!el) return false;
    try { el.click(); } catch(e){ el.dispatchEvent(new MouseEvent('click',{bubbles:true})); }
    return true;
    """, int(gi))


def wait_video(m, timeout=45):
    """等待播放器就绪（duration>0），返回视频状态或 None。"""
    end = time.time() + timeout
    while time.time() < end:
        m.switch_to_top()
        v = js(m, VIDEO_JS)
        if v and v.get("duration") and v["duration"] > 0:
            return v
        time.sleep(1.0)
    return None


def next_video_gi(items, current_gi):
    """从当前条目往后找下一个「视频」条目，返回 gi 或 None。"""
    for it in items:
        if it["gi"] > current_gi and it["tag"].find("视频") >= 0:
            return it["gi"]
    return None



# ---------------------------------------------------------------- 本地题库
def ask_bank(question, options=None, url="http://127.0.0.1:8791/api/answer", timeout=6):
    body = json.dumps({"question": question, "options": options or []}, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return {"found": False, "error": str(e)}


def pick_option(options, answer):
    """把题库答案映射到选项下标：支持 A/B/C、0/1/2、选项原文片段。"""
    if answer is None:
        return None
    a = str(answer).strip()
    m = re.match(r"^([A-Ha-h])$", a) or re.match(r"^([A-Ha-h])[.、．)）]", a)
    if m:
        idx = ord(m.group(1).upper()) - ord("A")
        return idx if 0 <= idx < len(options) else None
    if a.isdigit():
        idx = int(a)
        return idx if 0 <= idx < len(options) else None
    for i, o in enumerate(options):
        txt = o["text"] if isinstance(o, dict) else str(o)
        if a and (a == txt or a in txt or txt.endswith(a)):
            return i
    return None
