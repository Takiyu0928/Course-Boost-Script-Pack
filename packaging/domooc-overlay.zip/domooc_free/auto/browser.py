"""启动/复用带 Marionette 的 Firefox 实例（自动化用）。

路径全部相对推导，不写死盘符：
    包根  = auto/ 的上一级目录（也可用环境变量 DOMOOC_PKG 覆盖）
    App   = 包根\\App\\Firefox64\\firefox.exe

两种用法：
    · 正式自动化：由 启动domooc（自动化）.bat 用 -marionette 启动浏览器，本模块只负责连接
    · 自测：ensure(profile=make_test_profile(), headless=True) 用 Profile 副本，不碰你的登录态
"""

import os
import shutil
import socket
import subprocess
import tempfile
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get("DOMOOC_PKG") or os.path.dirname(HERE)
FF = os.path.join(PKG, "App", "Firefox64", "firefox.exe")
REAL_PROFILE = os.path.join(PKG, "Profile")
TEST_PROFILE = os.path.join(tempfile.gettempdir(), "domooc_autotest_profile")
PORT = 2828
LOG = os.path.join(HERE, "_browser.log")

SKIP_DIRS = {"cache2", "startupCache", "crashes", "minidumps", "datareporting",
             "safebrowsing", "shader-cache", "thumbnails", "sessionstore-backups",
             "https+++domooc.top", "to-be-removed"}
SKIP_FILES = {"parent.lock", "lock", "sessionstore.jsonlz4", "compatibility.ini"}


def port_open(port=PORT, host="127.0.0.1"):
    s = socket.socket()
    s.settimeout(0.4)
    try:
        s.connect((host, port))
        return True
    except Exception:
        return False
    finally:
        s.close()


def make_test_profile(force=False):
    """把正式 Profile 复制一份用于自测（不含缓存、不含锁）。"""
    if os.path.isdir(TEST_PROFILE) and not force:
        return TEST_PROFILE
    if os.path.isdir(TEST_PROFILE):
        shutil.rmtree(TEST_PROFILE, ignore_errors=True)

    def ignore(dirname, names):
        skip = set()
        for n in names:
            if n in SKIP_DIRS and os.path.isdir(os.path.join(dirname, n)):
                skip.add(n)
            elif n in SKIP_FILES:
                skip.add(n)
        return skip

    shutil.copytree(REAL_PROFILE, TEST_PROFILE, ignore=ignore, ignore_dangling_symlinks=True)
    return TEST_PROFILE


def ensure(profile=None, headless=True, wait=60, port=PORT):
    """确保有一个可连接的实例，返回 (pid 或 None, 是否本次启动)。"""
    if port_open(port):
        return None, False
    if not os.path.isfile(FF):
        raise RuntimeError("找不到 firefox.exe: %s" % FF)
    profile = profile or REAL_PROFILE
    args = [FF, "-marionette", "-no-remote", "-profile", profile]
    if headless:
        args.append("-headless")
    args.append("about:blank")
    logf = open(LOG, "ab")
    p = subprocess.Popen(args, stdout=logf, stderr=logf, cwd=os.path.dirname(FF))
    end = time.time() + wait
    while time.time() < end:
        if port_open(port):
            return p.pid, True
        if p.poll() is not None:
            raise RuntimeError("Firefox 启动即退出，exit=%s（看 _browser.log）" % p.returncode)
        time.sleep(0.4)
    raise RuntimeError("等待 Marionette 端口超时")


def quit_browser(port=PORT):
    if not port_open(port):
        return False
    sys.path.insert(0, HERE)
    from marionette import Marionette
    try:
        m = Marionette(port=port)
        m.new_session()
        m.quit()
    except Exception:
        pass
    for _ in range(40):
        if not port_open(port):
            return True
        time.sleep(0.3)
    return not port_open(port)


if __name__ == "__main__":
    if "--quit" in sys.argv:
        print("已退出" if quit_browser() else "没有运行中的实例")
    elif "--test-profile" in sys.argv:
        print(make_test_profile(force="--force" in sys.argv))
    else:
        pid, started = ensure()
        print("实例就绪", ("（本次启动 pid=%s）" % pid) if started else "（复用在跑的实例）")
