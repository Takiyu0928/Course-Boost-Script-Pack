"""domooc 本机版 · 自动化命令行入口（零第三方依赖）

先启动带 Marionette 的浏览器：
    双击  启动domooc（自动化）.bat        （用你自己的正式 Profile，登录态可保留）

命令：
    python run.py status                     当前页 / 登录态 / 我的课程地址
    python run.py login                      打开首页并等你手工登录
    python run.py courses                    列出「我的课程」里的课程与进度
    python run.py videos --course <CID>      列出该课程内容页的全部条目（视频/测验/讨论/文档）
    python run.py play --course <CID> --video 3 --speed 1.5
                                             打开第 3 个条目并真播放、盯到结束
    python run.py auto --course <CID> --speed 1.5 --minutes 180
                                             从第一个视频开始，逐条播放推进
    python run.py quiz --dry-run             识别当前页题目，按本地题库给出将点选的选项
    python run.py quiz                       按本地题库答题并点选（不提交）
    python run.py discover                   导出当前页结构到 _discover.json

可选：--port 2828、--launch real|test（没有实例时自己拉起）
"""

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import moocsite as S
from marionette import Marionette, MarionetteError

HERE = os.path.dirname(os.path.abspath(__file__))


def connect(args):
    port = args.port
    try:
        m = Marionette(port=port)
    except MarionetteError:
        if args.launch:
            import browser
            if args.launch == "test":
                browser.ensure(profile=browser.make_test_profile(), headless=True, port=port)
            else:
                browser.ensure(profile=os.path.join(browser.PKG, "Profile"), headless=False, port=port)
            m = Marionette(port=port)
        else:
            print("连接失败：Marionette 端口 %d 没有监听。" % port)
            print("请先双击 启动domooc（自动化）.bat，或加 --launch real。")
            raise SystemExit(2)
    try:
        m.new_session()
    except MarionetteError:
        pass
    m.switch_to_top()
    return m


def cmd_status(m, args):
    print("页面:", json.dumps(S.info(m), ensure_ascii=False, indent=1))
    print("登录态:", json.dumps(S.login_state(m), ensure_ascii=False))
    return 0


def cmd_login(m, args):
    m.navigate("https://www.icourse163.org/")
    S.settle(m)
    ok = S.wait_for_login(m, timeout=args.timeout)
    print("登录结果:", "成功" if ok else "超时未检测到登录态")
    return 0 if ok else 1


def cmd_courses(m, args):
    st = S.login_state(m)
    if not st["logged_in"]:
        print("未登录:", st.get("hint"))
        return 1
    print("用户 ID:", st["user_id"])
    m.navigate(st["my_course_url"])
    S.settle(m)
    for _ in range(12):
        if S.js(m, 'return document.querySelectorAll(\'a[href*="/learn/"]\').length'):
            break
        time.sleep(1.5)
    data = S.js(m, r"""
    var out = [], seen = {};
    document.querySelectorAll('a[href*="/learn/"]').forEach(function(a){
      var h = a.getAttribute('href') || '';
      var m2 = h.match(/\/learn\/([^#?]+)/);
      if (!m2 || seen[m2[1]]) return;
      seen[m2[1]] = 1;
      var box = a.closest('div[class],li'), info = '';
      for (var d=0; d<5 && box; d++){
        var t = (box.textContent||'').replace(/\s+/g,' ').trim();
        if (t.length > 8) info = t.slice(0, 90);
        box = box.parentElement;
      }
      out.push({cid: m2[1], info: info});
    });
    return out;
    """) or []
    print("共 %d 门课程：" % len(data))
    for i, c in enumerate(data, 1):
        print("  [%d] %-22s %s" % (i, c["cid"], c["info"][:78]))
    return 0


def cmd_videos(m, args):
    if not args.course:
        print("需要 --course <CID>（先用 python run.py courses 查）")
        return 2
    url = S.open_course(m, args.course)
    print("内容页:", url)
    items = S.list_items(m)
    if not items:
        print("没解析到条目，跑一次 discover 看结构")
        return 1
    videos = [i for i in items if "视频" in i["tag"]]
    print("共 %d 个条目，其中视频 %d 个（√=已学，*=视频）：" % (len(items), len(videos)))
    for it in items:
        if it.get("learned"):
            mark = "√"
        elif "视频" in it["tag"]:
            mark = "*"
        else:
            mark = " "
        print("  %s [%2d] %-4s %s / %s" % (mark, it["gi"], it["tag"] or "-", it["lessonTitle"][:18], it["title"][:40]))
    return 0


def _play_gi(m, gi, speed, minutes, label=""):
    ok = S.click_item(m, gi)
    if not ok:
        print("   点击条目失败:", gi)
        return "no_item"
    v = S.wait_video(m, timeout=45)
    if not v:
        print("   播放器未就绪（无 duration>0 的 video）")
        return "no_player"
    print("   %s 时长 %.0f 秒，开始播放 (x%s)" % (label, v["duration"], speed))
    S.video_play(m, speed=speed)
    res = S.watch(m, [], max_minutes=minutes,
                  on_tick=lambda v, note: print(
                      "     %s/%s %s" % (round(v["currentTime"], 1), round(v["duration"], 1), note or ""),
                      flush=True))
    print("   结果:", res["reason"])
    m.switch_to_top()
    return "ended" if res["ok"] else "partial"


def cmd_play(m, args):
    if not args.course:
        print("需要 --course <CID>")
        return 2
    S.open_course(m, args.course)
    items = S.list_items(m)
    if not items:
        print("没解析到条目")
        return 1
    target = None
    if args.video is not None:
        for it in items:
            if it["gi"] == args.video:
                target = it
                break
        if not target:
            print("条目下标越界（共 %d 个）" % len(items))
            return 2
    else:
        target = next((i for i in items if "视频" in i["tag"]), None)
        if not target:
            print("该课程没有视频条目")
            return 1
    print("目标条目 [%d] %s / %s" % (target["gi"], target["tag"], target["title"]))
    if args.dry_run:
        return 0
    status = _play_gi(m, target["gi"], args.speed, args.minutes,
                      "[%d]%s" % (target["gi"], target["title"][:24]))
    if status == "ended":
        return 0
    if status == "partial":
        print("   （未播完：时长超过本次上限，可加大 --minutes 继续）")
        return 0
    return 1


def cmd_auto(m, args):
    if not args.course:
        print("需要 --course <CID>")
        return 2
    S.open_course(m, args.course)
    items = S.list_items(m)
    videos = [i for i in items if "视频" in i["tag"]]
    if not videos:
        print("该课程没有视频条目")
        return 1
    learned = [i for i in videos if i.get("learned")]
    if args.video is not None:
        pending = [i for i in videos if i["gi"] >= args.video]
    elif args.force_all:
        pending = list(videos)
    else:
        pending = [i for i in videos if not i.get("learned")]
    print("课程 %s：视频 %d 个（已学 %d，待处理 %d），总时长上限 %s 分钟，倍速 x%s" % (
        args.course, len(videos), len(learned), len(pending), args.minutes, args.speed))
    if not pending:
        print("没有待处理的视频（全部显示已学）。可用 --video <下标> 强制从某条开始。")
        return 0
    deadline = time.time() + args.minutes * 60
    done = 0
    for idx, target in enumerate(pending):
        if time.time() >= deadline:
            print("\n到达时间上限，停止。")
            break
        remain = int((deadline - time.time()) / 60)
        print("== [%d/%d] %s / %s（剩余约 %d 分钟）" % (
            idx + 1, len(pending), target["lessonTitle"][:20], target["title"][:34], remain))
        S.open_course(m, args.course)
        items = S.list_items(m)
        cur = next((i for i in items if i["gi"] == target["gi"]), None)
        if not cur:
            print("   条目列表已变化，跳过")
            continue
        status = _play_gi(m, target["gi"], args.speed, min(args.video_minutes, remain or 1), "视频")
        if status == "ended":
            done += 1
            print("   √ 已播放完成")
        elif status == "partial":
            print("   本次只播放了一部分（时间上限），下次可继续")
            break
        else:
            print("   跳过（播放器未就绪）")
    print("\n完成 %d 个视频" % done)
    return 0


def cmd_quiz(m, args):
    fpath, data = S.extract_questions(m)
    if not data.get("count"):
        print("没识别到题目。若当前不是测验页，先点开一个「测验」条目再执行。")
        return 1
    S.enter_frames(m, fpath)
    print("识别到 %d 道题" % data["count"])
    hit = miss = 0
    for i, q in enumerate(data["questions"]):
        opts = [o["text"] for o in q["options"]]
        ans = S.ask_bank(q["q"], opts)
        line = "[%d] %s" % (i + 1, q["q"][:60])
        if ans.get("found"):
            idx = S.pick_option(q["options"], ans.get("answer"))
            if idx is None and ans.get("index") is not None:
                idx = int(ans["index"])
            if idx is None or idx >= len(q["options"]):
                print(line, "-> 题库答案映射不到选项:", ans.get("answer"))
                miss += 1
                continue
            hit += 1
            print(line, "-> 选中:", q["options"][idx]["text"][:40])
            if not args.dry_run:
                print("    点击:", json.dumps(S.click_option(m, q["q"], q["options"][idx]["text"]),
                                              ensure_ascii=False))
        else:
            miss += 1
            print(line, "-> 题库未收录，已记到 _pending.json")
            with open(os.path.join(HERE, "_pending.json"), "a", encoding="utf-8") as f:
                f.write(json.dumps({"q": q["q"], "type": q.get("type"), "options": opts},
                                   ensure_ascii=False) + "\n")
    print("命中 %d / 未命中 %d" % (hit, miss))
    return 0


def cmd_discover(m, args):
    if args.url:
        m.navigate(args.url)
        S.settle(m)
    report = {"info": S.info(m), "login": S.login_state(m) if args.with_login else None}
    vpath, v = S.find_video(m)
    report["video"] = {"found": bool(v), "state": v}
    m.switch_to_top()
    report["items"] = S.list_items(m)
    report["next_candidates"] = S.find_next_candidates(m)
    fp, qs = S.extract_questions(m)
    report["questions"] = {"count": qs.get("count"), "sample": (qs.get("questions") or [])[:5]}
    m.switch_to_top()
    report["dom"] = S.js(m, r"""
    (function(){
      function sig(el){
        var c = (el.className && typeof el.className === 'string')
          ? el.className.split(/\s+/).filter(Boolean).slice(0,3).join('.') : '';
        return el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (c ? '.' + c : '');
      }
      var counts = {}, tops = [];
      Array.prototype.forEach.call(document.querySelectorAll('*'), function(el){
        var s = sig(el); counts[s] = (counts[s] || 0) + 1;
        if (tops.length < 60 && counts[s] === 1) tops.push(s);
      });
      return {top: tops};
    })()
    """)
    out = os.path.join(HERE, "_discover.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print("已写出:", out)
    print("摘要:", json.dumps({
        "url": report["info"].get("url"),
        "video": report["video"]["found"],
        "items": len(report["items"]),
        "videos": len([i for i in report["items"] if "视频" in i["tag"]]),
        "questions": report["questions"]["count"],
    }, ensure_ascii=False))
    return 0


def main():
    ap = argparse.ArgumentParser(description="domooc 本机自动化")
    ap.add_argument("--port", type=int, default=2828)
    ap.add_argument("--launch", choices=["real", "test"], default=None)
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("status")
    p = sub.add_parser("login"); p.add_argument("--timeout", type=int, default=600)
    sub.add_parser("courses")

    p = sub.add_parser("videos"); p.add_argument("--course", default=None)

    p = sub.add_parser("play")
    p.add_argument("--course", default=None)
    p.add_argument("--video", type=int, default=None)
    p.add_argument("--speed", type=float, default=1.0)
    p.add_argument("--minutes", type=float, default=60)
    p.add_argument("--dry-run", action="store_true")

    p = sub.add_parser("auto")
    p.add_argument("--course", default=None)
    p.add_argument("--video", type=int, default=None, help="从这个条目下标开始")
    p.add_argument("--speed", type=float, default=1.0)
    p.add_argument("--minutes", type=float, default=120, help="总时长上限")
    p.add_argument("--video-minutes", type=float, default=120, help="单个视频上限")
    p.add_argument("--force-all", action="store_true",
                   help="连标记为已学（learned）的视频也重播")

    p = sub.add_parser("quiz")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--submit", action="store_true")

    p = sub.add_parser("discover")
    p.add_argument("--url", default=None)
    p.add_argument("--with-login", action="store_true")

    args = ap.parse_args()
    m = connect(args)
    fn = {"status": cmd_status, "login": cmd_login, "courses": cmd_courses,
          "videos": cmd_videos, "play": cmd_play, "auto": cmd_auto,
          "quiz": cmd_quiz, "discover": cmd_discover}[args.cmd]
    try:
        return fn(m, args)
    finally:
        try:
            m.sock.close()
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())
