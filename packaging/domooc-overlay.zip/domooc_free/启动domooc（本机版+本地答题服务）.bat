@echo off
rem ============================================================
rem  domooc local-only launcher + local answer service
rem  Pure ASCII on purpose (batch contents must not depend on any
rem  code page). Self-contained: it calls no other .bat file.
rem ============================================================
setlocal
cd /d "%~dp0"
title domooc local mode + answer service

set "ROOT=%~dp0"
set "SVC=%ROOT%answer-service"
set "PROFILE=%ROOT%Profile"
set "FF=%ROOT%App\Firefox64\firefox.exe"

if not exist "%FF%" (
  echo [ERROR] firefox.exe not found at: %FF%
  pause & exit /b 1
)
if not exist "%PROFILE%\user.js" (
  echo [ERROR] Profile\user.js is missing.
  echo         Remote channels would stay open - startup aborted.
  pause & exit /b 1
)

if exist "%PROFILE%\parent.lock" del /f /q "%PROFILE%\parent.lock" >nul 2>&1
if exist "%PROFILE%\lock"        del /f /q "%PROFILE%\lock" >nul 2>&1

set "SVCUP=0"
if exist "%SVC%\server.js" (
  where node >nul 2>&1
  if not errorlevel 1 (
    start "domooc answer service" /min /d "%SVC%" node server.js
    set "SVCUP=1"
    timeout /t 2 >nul
  )
)

echo Starting domooc in local-only mode ...
if "%SVCUP%"=="1" (
  echo   - local answer service: http://127.0.0.1:8791
) else (
  echo   - local answer service: NOT started ^(no Node.js or missing answer-service^)
  echo     only local-bank answering is affected; course play still works
)
echo   - domooc.top blocked inside the browser (local DNS override)
echo   - add-on / browser auto-update, telemetry, remote settings: OFF
echo.

start "" "%FF%" -profile "%PROFILE%" -no-remote
exit /b 0
